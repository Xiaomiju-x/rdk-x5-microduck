"""One named supported functional check; 3s at endpoint and 3s after return.

NOT walking/policy. Default plan only. Other joints remain at immutable R3.
Leg-lift snapshots are inside the previously executed suspended envelope.
"""
import argparse
import json
import signal
import time
from pathlib import Path
from sync_cycle_probe_20260927 import load_reference
from run_reposed_reference_air_20260928 import PROFILE,PORT,BUS_SHA
from head_retaught_r2_profile_20260928 import load_r3_roll14,R3_NAME,R3_SHA
from read_reposed_start_20260928 import decode
from operator_supervised_feedback_20260928 import decode_and_check,OperatorDispatchClock

STEPS={
 'lift_left':('左腿收腿抬脚',{3:-111,4:-238,5:24},'左膝折叠，左脚底升高；随后放回原位'),
 'lift_right':('右腿收腿抬脚',{8:120,9:211,10:-11},'右膝折叠，右脚底升高；随后放回原位'),
 'left_thigh':('左大腿前摆',{3:114},'左大腿和脚朝嘴巴方向摆动；随后返回'),
 'right_thigh':('右大腿前摆',{8:-114},'右大腿和脚朝嘴巴方向摆动；随后返回'),
 'left_knee':('左膝单独转动',{4:114},'大腿保持，左小腿及脚相对膝朝身后摆；随后返回'),
 'right_knee':('右膝单独转动',{9:-114},'大腿保持，右小腿及脚相对膝朝身后摆；随后返回'),
 'left_ankle':('左脚掌俯仰',{5:-114},'左脚尖向下压，腿上端不动；随后返回'),
 'right_ankle':('右脚掌俯仰',{10:114},'右脚尖向下压，腿上端不动；随后返回'),
 'left_roll':('左腿侧摆',{2:114},'左脚靠近另一条腿，即向身体中间收；随后返回'),
 'right_roll':('右腿侧摆',{7:114},'右脚远离另一条腿，即向外侧摆；随后返回'),
 'left_yaw':('左腿根转向',{1:114},'左脚尖向鸭子自身外侧转；随后返回'),
 'right_yaw':('右腿根转向',{6:114},'右脚尖向鸭子身体中间转；随后返回'),
 'neck_root':('颈根前倾',{11:-114},'脖子连头朝嘴巴方向前倾；随后返回'),
 'head_pitch':('头部后仰',{12:-114},'头部后仰、嘴尖抬高；随后返回'),
 'head_yaw':('向右转头',{13:114},'嘴巴朝鸭子自身右边转；随后返回'),
 'head_roll':('向右歪头',{14:114},'头顶偏向鸭子自身右侧；随后摆正'),
 'mouth':('嘴巴开合',{15:-228},'嘴巴张开约20度，停住，再回原开合位置')
}


def frames_for(step,start):
    _,delta,_=STEPS[step]
    peak={i:start[i]+delta.get(i,0) for i in start}
    if any(not 0<=p<=4095 or abs(p-start[i])>284 for i,p in peak.items()):
        raise ValueError('Outside previously explored envelope')
    frames=[(dict(start),'PREPARE') for _ in range(50)]
    def ramp(a,b,name):
        for k in range(1,76):
            u=k/75;v=u*u*(3-2*u)
            frames.append(({i:round(a[i]+(b[i]-a[i])*v) for i in a},name))
    ramp(start,peak,'MOVE_TO_CHECK_POSE')
    frames.extend((dict(peak),'HOLD_3_SECONDS_OBSERVE') for _ in range(150))
    ramp(peak,start,'RETURN_TO_R3')
    frames.extend((dict(start),'HOLD_R3_3_SECONDS') for _ in range(150))
    return frames


class CheckSerial:
    def __init__(self,raw,active,start,peak):
        self.raw=raw;self.active=tuple(sorted(active));self.start=start;self.peak=peak
        self.allowed=None;self.count=0
    def write(self,p):
        if len(p)<6 or p[:2]!=b'\xff\xff' or len(p)!=p[3]+4 or sum(p[2:])%256!=255:
            raise ValueError('Malformed packet')
        sid,op,args=p[2],p[4],p[5:-1]
        read=op==2 and 1<=sid<=15 and args in (bytes([0,66]),bytes([40,26]))
        if not read:
            if self.allowed is None:raise ValueError('No pending reviewed frame')
            f=self.allowed
            for i in self.start:
                low,high=sorted((self.start[i],self.peak[i]))
                if not low<=f[i]<=high:raise ValueError('Outside this check segment')
            wanted=bytes([42,2])+b''.join(bytes([i,f[i]&255,f[i]>>8]) for i in self.active)
            if sid!=254 or op!=0x83 or args!=wanted:raise ValueError('No other target/config/torque write allowed')
            self.allowed=None;self.count+=1
        n=self.raw.write(p)
        if n!=len(p):raise IOError('Partial transmit')
        return n
    def __getattr__(self,k):return getattr(self.raw,k)


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--step',choices=STEPS,required=True)
    cli.add_argument('--execute-supported',action='store_true')
    args=cli.parse_args();root=Path(__file__).resolve().parent
    cfg=load_r3_roll14(root,json.loads((root/PROFILE).read_text(encoding='utf8')))
    start={int(i):p for i,p in cfg['targets'].items()};frames=frames_for(args.step,start)
    label,delta,expected_description=STEPS[args.step];active=tuple(sorted(delta))
    print(json.dumps(dict(step=args.step,label=label,expected=expected_description,
        delta_raw=delta,seconds=len(frames)*.02,execute=args.execute_supported),ensure_ascii=False),flush=True)
    if not args.execute_supported:return
    cls,sha=load_reference(root/'reference_feetech.py')
    if sha!=BUS_SHA:raise ValueError('Bus changed')
    import serial
    guard=CheckSerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True),active,start,
                      {i:start[i]+delta.get(i,0) for i in start})
    bus=cls(PORT,ser=guard);goals=dict(start);clock=OperatorDispatchClock()
    result=dict(scope='SUPPORTED_FULL_BODY_FUNCTION_CHECK_NOT_GAIT',step=args.step,label=label,
        expected=expected_description,profile=R3_NAME,profile_sha256=R3_SHA,active_ids=active,
        samples=[],status='PREFLIGHT',user_observation=None,torque_writes=0,configuration_writes=0)
    def full():
        out={}
        for i in range(1,16):
            err,data=bus.read(i,0,66);q=decode(data)
            decode_and_check(i,err,data,0,goals)
            if q['id']!=i or q['mode']!=4 or q['offset']!=cfg['expected_offsets_raw'][str(i)]:
                raise ValueError('Changed identity/coordinate/mode')
            out[i]=q
        return out
    def cancel(*_):raise RuntimeError('Interrupted: hold last goal; no auto release or reset')
    signal.signal(signal.SIGINT,cancel);signal.signal(signal.SIGTERM,cancel)
    try:
        result['before']=full();epoch=time.monotonic();others=[i for i in start if i not in active]
        for k,(frame,stage) in enumerate(frames):
            begun=clock.before_read();state={}
            for i in active:state[i]=decode_and_check(i,*bus.read(i,40,26),40,goals)
            other=others[k%len(others)]
            state[other]=decode_and_check(other,*bus.read(other,40,26),40,goals)
            if time.monotonic()-epoch>20:raise RuntimeError('Finite check deadline')
            timing=clock.before_dispatch(begun);guard.allowed=frame
            bus.sync_write(42,2,[(i,frame[i].to_bytes(2,'little')) for i in active]);guard.raw.flush()
            goals=dict(frame)
            result['samples'].append(dict(frame=k,stage=stage,state_before_command=state,
                next_targets={i:frame[i] for i in active},timing=timing))
            if k==0 or stage!=frames[k-1][1]:print(json.dumps(dict(frame=k,stage=stage)),flush=True)
        result['after']=full();result['status']='FUNCTION_CHECK_COMPLETE_R3_HELD_USER_VERDICT_PENDING'
    except BaseException as exc:
        result.update(status='STOPPED_KEEP_LAST_TARGET_NO_AUTO_RELEASE',failure=repr(exc),last_targets=goals)
        raise
    finally:
        result['motion_target_packets']=guard.count;result['bus_stats']=dict(bus.stats);bus.close()
        result['serial_closed']=True
        path=root/('full_check_'+args.step+'_'+str(time.time_ns())+'.json')
        path.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('samples','before','after')},ensure_ascii=False),flush=True)
        print('LOG '+str(path),flush=True)


if __name__=='__main__':main()
