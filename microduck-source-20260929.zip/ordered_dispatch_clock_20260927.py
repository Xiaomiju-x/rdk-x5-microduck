"""Ordered position-frame pacing for a supervised finite experiment.

18ms is an IO performance budget, not a servo health fault. Complete, healthy
feedback may delay the NEXT frame, but frames are never skipped or sent in a
catch-up burst. This is not a real-time/balance or hardware-watchdog guarantee.
"""
import time


class OrderedDispatchClock:
    def __init__(self,clock=time.monotonic,sleep=time.sleep):
        self.clock=clock;self.sleep=sleep;self.last_dispatch=None;self.soft_overruns=0
    def _until(self,due):
        while True:
            remaining=due-self.clock()
            if remaining<=0:return
            self.sleep(remaining)
    def before_read(self):
        if self.last_dispatch is not None:self._until(self.last_dispatch+.006)
        return self.clock()
    def before_dispatch(self,read_begun):
        read_ms=(self.clock()-read_begun)*1000
        if read_ms>50:raise RuntimeError(f'Fresh state acquisition exceeded 50ms: {read_ms:.3f}')
        soft=read_ms>18
        if soft:self.soft_overruns+=1
        if self.last_dispatch is not None:self._until(self.last_dispatch+.02)
        now=self.clock()
        interval=None if self.last_dispatch is None else (now-self.last_dispatch)*1000
        if interval is not None and interval>60:
            raise RuntimeError(f'Dispatch gap exceeded 60ms: {interval:.3f}')
        self.last_dispatch=now
        return dict(dispatch_mono_s=now,dispatch_interval_ms=interval,
                    read_ms=read_ms,read_soft_budget_exceeded=soft)
