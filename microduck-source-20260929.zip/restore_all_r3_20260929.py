"""Explicit supported capture/enable and slow return of ALL15 to saved R3.

No ID/offset/PID/EEPROM writes, no automatic disable, no gait. Defaults to a
file-only plan. The only enable fallback is 40=1 for a just-captured motor.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path
from read_reposed_start_20260928 import PROFILE,PORT,decode
from head_retaught_r2_profile_20260928 import load_r3_roll14,R3_SHA
from sync_cycle_probe_20260927 import load_reference
from run_reposed_reference_air_20260928 import BUS_SHA

IDS=tuple(range(1,16))


def recovery_frames(initial,target):
    if set(initial)!=set(IDS) or set(target)!=set(IDS):raise ValueError('All15 required')
    for i in IDS:
        if any(type(v) is not int or not 0<=v<=4095 for v in (initial[i],target[i])):
            raise ValueError('Invalid encoder coordinate')
        if abs(initial[i]-target[i])>512:raise ValueError('More than45deg from R3: no blind restore')
    n=max(1,math.ceil(max(abs(initial[i]-target[i]) for i in IDS)/6))
    return [{i:round(initial[i]+(target[i]-initial[i])*k/n) for i in IDS} for k in range(1,n+1)]


class RestoreSerial:
    def __init__(self,raw):self.raw=raw;self.allowed=None;self.write_count=0
    def allow(self,sid,op,args):
        if sid not in (*IDS,254):raise ValueError('ID scope')
        valid=(op==3 and sid in IDS and (args==bytes([40,1]) or len(args)==3 and args[0]==42))
        valid=valid or (op==0x83 and sid==254 and len(args)==47 and args[:2]==bytes([42,2]) and tuple(args[2::3])==IDS)
        if not valid:raise ValueError('Only volatile target or enable-one writes')
        b=bytes([sid,len(args)+2,op])+args
        self.allowed=b'\xff\xff'+b+bytes([255-sum(b)%256])
    def write(self,p):
        if len(p)<6 or p[:2]!=b'\xff\xff' or len(p)!=p[3]+4 or sum(p[2:])%256!=255:raise ValueError('Bad frame')
        is_read=p[4]==2 and p[2] in IDS and p[5:-1]==bytes([0,66])
        if not is_read:
            if self.allowed is None or p!=self.allowed:raise ValueError('Unexpected write')
            self.allowed=None;self.write_count+=1
        n=self.raw.write(p)
        if n!=len(p):raise IOError('Partial serial write')
        return n
    def __getattr__(self,key):return getattr(self.raw,key)


def main(argv=None,panel_progress=None,cancel_check=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--restore-supported',action='store_true');a=p.parse_args(argv)
    root=Path(__file__).resolve().parent
    cfg=load_r3_roll14(root,json.loads((root/PROFILE).read_text(encoding='utf8')))
    target={int(k):v for k,v in cfg['targets'].items()}
    offsets={int(k):v for k,v in cfg['expected_offsets_raw'].items()}
    print(json.dumps(dict(profile_sha256=R3_SHA,execute=a.restore_supported,targets=target)),flush=True)
    if not a.restore_supported:return
    cls,sha=load_reference(root/'reference_feetech.py')
    if sha!=BUS_SHA:raise ValueError('Bus source mismatch')
    import serial
    guard=RestoreSerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True))
    bus=cls(PORT,ser=guard)
    result=dict(status='PREFLIGHT',profile_sha256=R3_SHA,captures=[],frames=[],after_rounds=[],
                configuration_writes=0,disable_writes=0)
    path=root/('restore_all_r3_'+str(time.time_ns())+'.json')
    def read(i):
        err,data=bus.read(i,0,66);q=decode(data)
        if q['id']!=i or q['mode']!=4 or q['offset']!=offsets[i] or (err&~1) or (q['error']&~1):
            raise RuntimeError('Coordinate or non-voltage fault '+str((i,q)))
        if not 0<=q['pos']<=4095 or q['torque'] not in (0,1):raise RuntimeError('Invalid state '+str((i,q)))
        return q
    def one_write(i,address,data):
        if cancel_check is not None:cancel_check()
        guard.allow(i,3,bytes([address])+data);bus.write(i,address,data);time.sleep(.025)
    try:
        before={i:read(i) for i in IDS};result['before']=before
        current={i:(q['pos'] if q['torque']==0 else q['target']) for i,q in before.items()}
        recovery_frames(current,target)  # validate entire plan before enabling any axis
        for i in IDS:
            if before[i]['torque']==0:
                q=read(i)
                if abs(q['pos']-current[i])>12:raise RuntimeError('Servo moving during capture '+str(i))
                current[i]=q['pos']
                result['captures'].append(dict(id=i,target=current[i]))
                one_write(i,42,current[i].to_bytes(2,'little'))
                q=read(i)
                if q['torque']==0:one_write(i,40,bytes([1]));q=read(i)
                if q['torque']!=1 or q['target']!=current[i]:raise RuntimeError('Capture/enable not confirmed')
        planned=recovery_frames(current,target)
        for step,f in enumerate(planned):
            if cancel_check is not None:cancel_check()
            args=bytes([42,2])+b''.join(bytes([i,f[i]&255,f[i]>>8]) for i in IDS)
            guard.allow(254,0x83,args)
            bus.sync_write(42,2,[(i,f[i].to_bytes(2,'little')) for i in IDS]);guard.raw.flush()
            time.sleep(.10)
            state={i:read(i) for i in IDS}
            result['frames'].append(dict(targets=f,state=state))
            if any(state[i]['torque']!=1 or state[i]['target']!=f[i] for i in IDS):
                raise RuntimeError('Enable or accepted target changed during restore')
            if panel_progress is not None:panel_progress(dict(frame=step,total=len(planned),phase='RESTORE_R3'))
        for _ in range(3):
            time.sleep(.10);state={i:read(i) for i in IDS};result['after_rounds'].append(state)
            if any(state[i]['torque']!=1 or state[i]['target']!=target[i] for i in IDS):
                raise RuntimeError('Final R3 target/enable mismatch')
        result['max_final_error_counts']=max(abs(q['pos']-target[i]) for i,q in state.items())
        result['status']='ALL15_ENABLED_EXACT_R3_TARGETS_RESTORED'
    except BaseException as exc:
        result.update(status='INCOMPLETE_LAST_TARGETS_HELD_NO_AUTO_RELEASE',failure=repr(exc));raise
    finally:
        result['bus_stats']=dict(bus.stats);result['volatile_write_packets']=guard.write_count
        bus.close();result['serial_closed']=True
        path.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps(dict(status=result['status'],captures=len(result['captures']),steps=len(result['frames']),
            max_final_error_counts=result.get('max_final_error_counts'),bus_stats=result['bus_stats'],log=str(path))),flush=True)
    return result

if __name__=='__main__':main()
