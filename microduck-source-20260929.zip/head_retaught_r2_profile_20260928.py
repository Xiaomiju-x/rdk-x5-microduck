"""Exact R2 pose selection; only fixed head11..14 differs from leg baseline."""
import hashlib
import json

NAME='FT_START_POSE_20260928_HEAD_RETAUGHT_R2.json'
SHA='395ef423eeef716c977270611c2980329d041642eeb28453d9dbfee766679739'
R3_NAME='FT_START_POSE_20260928_HEAD_RETAUGHT_R3_ROLL14.json'
R3_SHA='527a712f068fa4ba51da832a2fa743ad9dd690dbe98825949a6b62b0a469fca3'


def load_r2(root,original):
    path=root/NAME
    if hashlib.sha256(path.read_bytes()).hexdigest()!=SHA:raise ValueError('R2 pose hash changed')
    cfg=json.loads(path.read_text(encoding='utf8'))
    if cfg['expected_offsets_raw']!=original['expected_offsets_raw']:raise ValueError('Coordinate map changed')
    if set(cfg['targets'])!=set(original['targets']):raise ValueError('ID set changed')
    for i in (*range(1,11),15):
        if cfg['targets'][str(i)]!=original['targets'][str(i)]:raise ValueError('Leg/mouth target changed')
    if [cfg['targets'][str(i)] for i in (11,12,13,14)]!=[2946,2230,2276,1046]:
        raise ValueError('Unexpected R2 head targets')
    return cfg


def retarget_fixed_head(frames,cfg):
    for i in (11,12,13,14):
        if any(f[i]!=frames[0][i] for f in frames):raise ValueError('Not a fixed-head base trajectory')
    result=[]
    for frame in frames:
        row=dict(frame)
        for i in (11,12,13,14):row[i]=cfg['targets'][str(i)]
        result.append(row)
    if result[0]!={int(i):p for i,p in cfg['targets'].items()} or result[-1]!=result[0]:
        raise ValueError('R2 endpoints mismatch')
    return result


def load_r3_roll14(root,original):
    parent=load_r2(root,original);path=root/R3_NAME
    if hashlib.sha256(path.read_bytes()).hexdigest()!=R3_SHA:raise ValueError('R3 roll14 hash changed')
    cfg=json.loads(path.read_text(encoding='utf8'))
    if cfg['expected_offsets_raw']!=parent['expected_offsets_raw'] or cfg.get('changed_ids')!=[14]:
        raise ValueError('Not a roll14-only update')
    if set(cfg['targets'])!=set(parent['targets']):raise ValueError('ID set changed')
    if any(cfg['targets'][i]!=p for i,p in parent['targets'].items() if i!='14'):
        raise ValueError('Another joint changed')
    if cfg['targets']['14']!=957:raise ValueError('Wrong new roll reference')
    return cfg
