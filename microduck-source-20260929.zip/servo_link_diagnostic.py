"""Read-only comparison: legacy fixed read versus framed reception. No motion writes."""
import argparse
import json
import time
from pathlib import Path


def extract(buffer, servo_id, parameters):
    """Consume framed packets, rejecting noise, wrong ID/length/checksum."""
    rejected = 0
    while len(buffer) >= 4:
        if buffer[:2] != b'\xff\xff':
            del buffer[0]
            rejected += 1
            continue
        length = buffer[3]
        if not 2 <= length <= 246 or buffer[2] > 253:
            del buffer[0]
            rejected += 1
            continue
        if len(buffer) < length + 4:
            break
        frame = bytes(buffer[:length + 4])
        if sum(frame[2:]) % 256 != 255:
            del buffer[0]
            rejected += 1
            continue
        del buffer[:length + 4]
        if frame[2] != servo_id or length != parameters + 2:
            rejected += 1
            continue
        if frame[4]:
            raise RuntimeError('Servo status error: ' + frame.hex())
        return frame, rejected
    return None, rejected


def framed_read(port, servo_id, count=66, deadline_s=.2):
    buffer = bytearray()
    received = bytearray()
    discarded = 0
    deadline = time.monotonic() + deadline_s
    while time.monotonic() < deadline:
        data = port.read(max(1, port.in_waiting))
        buffer.extend(data)
        received.extend(data)
        frame, rejected = extract(buffer, servo_id, count)
        discarded += rejected
        if frame is not None:
            return frame, discarded, bytes(received)
    raise TimeoutError('No complete matching frame; raw=' + received.hex())


def main():
    import serial
    parser = argparse.ArgumentParser()
    parser.add_argument('--rounds', type=int, default=10)
    args = parser.parse_args()
    assert 1 <= args.rounds <= 20
    path = '/dev/serial/by-id/SELECT_SERVO_ADAPTER'
    records = []
    with serial.Serial(path, 1000000, timeout=.01, write_timeout=.2, exclusive=True) as port:
        for mode in ('legacy', 'framed'):
            for sweep in range(args.rounds):
                for servo_id in range(1, 16):
                    entry = dict(mode=mode, sweep=sweep, id=servo_id)
                    port.reset_input_buffer()
                    body = [servo_id, 4, 2, 0, 66]
                    tick = time.monotonic()
                    port.write(bytes([255, 255] + body + [255-sum(body)%256]))
                    port.flush()
                    try:
                        if mode == 'legacy':
                            port.timeout = .2
                            frame = port.read(72)
                            entry['raw'] = frame.hex()
                            if len(frame) != 72 or frame[:4] != bytes([255,255,servo_id,68]) or sum(frame[2:])%256 != 255 or frame[4]:
                                raise RuntimeError('Invalid legacy reply')
                        else:
                            port.timeout = .01
                            frame, entry['discarded'], raw = framed_read(port, servo_id)
                            entry['raw'] = raw.hex()
                        data = frame[5:-1]
                        entry.update(ok=True, torque=data[40], target=data[42]+256*data[43],
                                     pos=data[56]+256*data[57], voltage=data[62]/10,
                                     temp=data[63], error=data[65], offset=data[31]+256*data[32])
                    except Exception as exc:
                        entry.update(ok=False, failure=str(exc))
                    entry['elapsed_ms'] = round((time.monotonic()-tick)*1000, 3)
                    records.append(entry)
                    time.sleep(.005)
                if sweep % 5 == 0:
                    print(json.dumps(dict(mode=mode, sweep=sweep, failures=sum(not x['ok'] for x in records if x['mode']==mode))), flush=True)
    result = {mode: dict(total=sum(x['mode']==mode for x in records),
                        failed=sum(x['mode']==mode and not x['ok'] for x in records)) for mode in ('legacy','framed')}
    output = Path(__file__).with_name('link_readonly_' + str(time.time_ns()) + '.json')
    output.write_text(json.dumps(dict(summary=result, records=records), indent=2))
    print(json.dumps(dict(summary=result, log=str(output))), flush=True)


if __name__ == '__main__':
    main()
