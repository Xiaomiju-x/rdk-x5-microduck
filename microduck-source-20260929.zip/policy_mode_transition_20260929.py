"""Explicit finite stand/walk actor crossfade, not continuous action filtering.

Both original actors see fresh state and the same previously applied raw action.
The mixed raw action becomes last_action. Outside the declared transition, the
selected actor is unfiltered. No hardware API, no changes to weights or scales.
This is an experimental runtime change, not the original author's deployment.
"""
import numpy as np
from ft_policy_adapter_20260928 import DEFAULT, observation, vec


class PolicyModeTransition:
    def __init__(self, original, seconds=.6):
        if seconds not in (0., .6):
            raise ValueError('Only baseline or explicit 0.6s transition')
        self.original = original
        self.seconds = seconds
        self.mode = 'standing'
        self.old_mode = None
        self.transition_tick = 0
        self.walk_command = None

    def step(self, q, qdot, gyro, gravity, command):
        if self.seconds == 0:
            return self.original.step(q, qdot, gyro, gravity, command)
        cmd = vec(command, 13)
        wanted = 'standing' if np.linalg.norm(cmd[:3]) <= .05 else 'walking'
        if wanted == 'walking':
            self.walk_command = cmd.copy()
        if wanted != self.mode:
            if self.old_mode is not None:
                raise ValueError('Second actor switch before first transition finished')
            self.old_mode, self.mode = self.mode, wanted
            self.transition_tick = 0
        alpha = 1.
        if self.old_mode is not None:
            u = min(1., self.transition_tick*.02/self.seconds)
            alpha = u*u*(3-2*u)

        def evaluate(mode):
            actor_command = cmd.copy()
            if mode == 'standing':
                actor_command[:3] = 0
            elif wanted == 'standing':
                if self.walk_command is None:
                    raise ValueError('No preceding walking command')
                # Retain preceding twist only during the bounded walk->stand
                # crossfade; do not accidentally run walking actor at zero.
                actor_command[:3] = self.walk_command[:3]
            obs = observation(q, qdot, gyro, gravity, self.original.last_action, actor_command)
            action, _ = self.original.evaluate(obs, mode)
            return obs, vec(action,14)

        obs, selected = evaluate(self.mode)
        prior = None
        action = selected
        if self.old_mode is not None and alpha < 1:
            _, prior = evaluate(self.old_mode)
            action = ((1-alpha)*prior + alpha*selected).astype(np.float32)
        action = vec(action,14)
        self.original.last_action = action.copy()
        result = dict(mode=self.mode, observation=obs.tolist(), action_raw=action.tolist(),
                      policy_target_rad=(DEFAULT+action).astype(np.float32).tolist(), action_scale=1.,
                      actor_transition_seconds=self.seconds, actor_transition_alpha=alpha,
                      actor_transition_from=self.old_mode,
                      selected_actor_action_raw=selected.tolist(),
                      previous_actor_action_raw=None if prior is None else prior.tolist())
        if self.old_mode is not None:
            if alpha >= 1:
                self.old_mode = None
            else:
                self.transition_tick += 1
        return result
