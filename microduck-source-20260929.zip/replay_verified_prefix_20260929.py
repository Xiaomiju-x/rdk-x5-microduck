"""One supervised replay of the operator-approved prefix's SENT TARGETS.

Not live RL, not a replay of actual joint angles, not a looping gait. The first
250 goals and their intervals come from one hash-pinned receipt (150 prepare +
100 policy ticks). Only the 100-tick smooth return and 50-tick R3 hold are new.
By default IMU is passive and never changes these targets. The separate explicit
neck-back-compensation flag changes only ID11 using relative-pitch feedback;
all other sent goals remain exact. No torque/EEPROM writes.
"""
import argparse
import hashlib
import json
import signal
import time
from pathlib import Path

from live_policy_air_preview_20260928 import (
    prepare, IDS, CAP_DEG, SLEW_COUNTS, AirPolicySerial, PORT, BUS_SHA,
    load_reference, decode, decode_and_check, R3_SHA)
from bounded_head_read_20260929 import BoundedHeadRead
from confirm_position_write_20260929 import confirm_position_write
from imu_trace_20260927 import ImuTrace

SOURCE='live_policy_ground_trial_1790662489018534868.json'
SOURCE_SHA='25d200ba0cc51dc740c0ef8038e2d1a2f2a850a3df4ea907f15ee8c9c31b2f73'


def stream_sha(frames,ids=tuple(range(1,16))):
    goals=[[f['target'][i] for i in ids] for f in frames]
    return hashlib.sha256(json.dumps(goals,separators=(',',':')).encode()).hexdigest()


def check_target(target,start,previous):
    if set(target)!=set(start) or target[15]!=start[15]:
        raise ValueError('Full15 targets and fixed mouth required')
    for i in IDS:
        if type(target[i]) is not int or not 0<=target[i]<=4095:
            raise ValueError('Invalid encoder goal')
        if abs(target[i]-start[i])>round(CAP_DEG[i]*4096/360):
            raise ValueError('Amplitude outside previously tested envelope')
        if abs(target[i]-previous[i])>SLEW_COUNTS[i]:
            raise ValueError('Slew outside previously tested envelope')


def load_plan(root):
    source=root/SOURCE
    if not source.exists():source=root/'calibration_20260926'/SOURCE
    raw=source.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SOURCE_SHA:
        raise ValueError('Immutable source receipt changed')
    record=json.loads(raw)
    cfg,*_=prepare(root)
    start={int(i):v for i,v in cfg['targets'].items()}
    if (record['profile_sha256']!=R3_SHA or len(record['events'])!=630
        or record['status']!='BOUNDED_GROUND_EXPERIMENT_COMPLETE_R3_HELD_ONSITE_RESULT_PENDING'):
        raise ValueError('Not the completed video-associated source receipt')
    frames=[];previous=dict(start)
    for k,e in enumerate(record['events'][:250]):
        expected_phase='PREPARE_GROUND_ONSITE' if k<150 else 'LIVE_STAND'
        if e['frame']!=k or e['phase']!=expected_phase:
            raise ValueError('Wrong source prefix')
        if k>=150 and (e['policy']['mode']!='standing'
                       or any(e['policy']['observation'][48:51])):
            raise ValueError('Walking command cannot enter this prefix')
        target={int(i):v for i,v in e['sent_targets'].items()}
        check_target(target,start,previous)
        if k<150 and target!=start:raise ValueError('Prepare source is not R3')
        if any(e['state_before_command'][str(i)]['target']!=previous[i] for i in start):
            raise ValueError('Source accepted-goal chain inconsistent')
        interval=.02 if k==0 else e['t_s']-record['events'][k-1]['t_s']
        if not .018<=interval<=.05:raise ValueError('Source timing outside bounded window')
        frames.append(dict(target=target,interval_s=interval,source_frame=k,
            phase='PREPARE_EXACT_R3' if k<150 else 'EXACT_SENT_TARGET_PREFIX'))
        previous=target
    origin=dict(previous)
    for k in range(1,101):
        u=k/100;weight=u*u*(3-2*u)
        target={i:round(origin[i]+(start[i]-origin[i])*weight) for i in start}
        check_target(target,start,previous)
        frames.append(dict(target=target,interval_s=.02,source_frame=None,phase='GENERATED_SMOOTH_R3'))
        previous=target
    for _ in range(50):
        frames.append(dict(target=dict(start),interval_s=.02,source_frame=None,phase='FINAL_R3_HOLD'))
    if len(frames)!=400 or frames[0]['target']!=start or frames[-1]['target']!=start:
        raise ValueError('Finite R3 endpoints required')
    return cfg,start,frames


def main(argv=None,panel_parameters=None,panel_progress=None,cancel_check=None):
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--execute-with-onsite-catch',action='store_true')
    cli.add_argument('--neck-back-compensation',action='store_true',
        help='Explicit new experiment: only ID11 adds <=8deg verified backward compensation; legs unchanged.')
    cli.add_argument('--neck-correction-scale',type=float,choices=(.5,1.),default=1.,
        help='Explicitly halve both the neck response gain and its cap; other controls unchanged.')
    args=cli.parse_args(argv)
    if args.neck_correction_scale!=1. and not args.neck_back_compensation:
        cli.error('--neck-correction-scale requires --neck-back-compensation')
    if panel_parameters is not None and (not args.neck_back_compensation or args.neck_correction_scale!=1.):
        cli.error('Explicit panel parameters require compensation without correction-scale')
    root=Path(__file__).resolve().parent
    cfg,start,frames=load_plan(root)
    unchanged_ids=[i for i in range(1,16) if not (args.neck_back_compensation and i==11)]
    neck=None;rotation=None
    if args.neck_back_compensation:
        from neck_prefix_compensation_20260929 import NeckPrefixCompensation
        from ft_policy_adapter_20260928 import gravity_from_rpy_deg
        import numpy as np
        neck=NeckPrefixCompensation(args.neck_correction_scale,parameters=panel_parameters)
        *_,rotation=prepare(root)
    out=dict(scope=('SUPERVISED_RECORDED_TARGETS_WITH_ID11_RELATIVE_COMPENSATION' if neck is not None
                    else 'SUPERVISED_EXACT_SENT_TARGET_PREFIX_NOT_CONTINUOUS_WALKING'),
        execute=args.execute_with_onsite_catch,source=SOURCE,source_sha256=SOURCE_SHA,
        profile_sha256=R3_SHA,frames_planned=len(frames),duration_planned_s=sum(f['interval_s'] for f in frames),
        exact_source_prefix_frames=250,exact_policy_source_frames=[150,249],
        source_prefix_target_sha256=stream_sha(frames[:250]),
        exact_motion_target_sha256=stream_sha(frames[150:250]),
        neck_back_compensation=args.neck_back_compensation,
        panel_parameters=panel_parameters,
        neck_correction_scale=neck.correction_scale if neck is not None else None,
        neck_response_gain=neck.gain if neck is not None else None,
        neck_max_back_deg=neck.max_back_deg if neck is not None else None,
        source_unchanged_ids=unchanged_ids,
        source_unchanged_prefix_sha256=stream_sha(frames[:250],unchanged_ids),
        neck_module_sha256=(hashlib.sha256((root/'neck_prefix_compensation_20260929.py').read_bytes()).hexdigest()
                            if neck is not None else None),
        controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        policy_evaluation=False,measured_actual_replayed=False,
        imu_role='RELATIVE_PITCH_FEEDBACK_FOR_ID11_ONLY' if neck is not None else 'PASSIVE_NOT_ACTION_INPUT',
        source_timing_replayed=True,catch_up_bursts=False,automatic_repeats=0,
        torque_writes=0,configuration_writes=0,status='PLAN_ONLY')
    print(json.dumps(out),flush=True)
    if not args.execute_with_onsite_catch:return
    cls,sha=load_reference(root/'reference_feetech.py')
    if sha!=BUS_SHA:raise ValueError('Bus source changed')
    import serial
    guard=AirPolicySerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True),start)
    bus=cls(PORT,ser=guard)
    reader=BoundedHeadRead(bus,cls.read.__globals__['BusTimeout'],serial.SerialTimeoutException)
    imu=ImuTrace();expected=dict(start)
    out.update(events=[],ambiguous_write_events=[],status='PREFLIGHT')
    def full():
        states={}
        for i in range(1,16):
            err,data=bus.read(i,0,66)
            q=decode(data);decode_and_check(i,err,data,0,expected)
            if q['id']!=i or q['mode']!=4 or q['offset']!=cfg['expected_offsets_raw'][str(i)]:
                raise ValueError('ID/mode/offset changed')
            states[i]=q
        return states
    def cancel(*_):raise RuntimeError('Interrupted: hold last goals, no auto release/reset')
    signal.signal(signal.SIGINT,cancel);signal.signal(signal.SIGTERM,cancel)
    try:
        out['before']=full();imu.start();epoch=time.monotonic();last=None
        for k,frame in enumerate(frames):
            if cancel_check is not None:cancel_check()
            begun=time.monotonic()
            rows=bus.sync_read(list(range(1,11)),40,26)
            for i in range(11,16):rows[i]=reader.read(i,k)
            if set(rows)!=set(start) or any(v is None for v in rows.values()):
                raise RuntimeError('Incomplete actuator feedback')
            state={i:decode_and_check(i,*rows[i],40,expected) for i in rows}
            for i,(_,data) in rows.items():
                state[i].update(speed_raw=data[18]+256*data[19],load_raw=data[20]+256*data[21])
            if last is not None:time.sleep(max(0,last+frame['interval_s']-time.monotonic()))
            if time.monotonic()-epoch>20:raise RuntimeError('Finite replay deadline')
            target=dict(frame['target']);neck_log=None
            if neck is not None:
                snapshot=imu.snapshot()
                if not snapshot or snapshot['error'] or snapshot['host_age_ms']>150:
                    raise RuntimeError('Fresh IMU required for new neck feedback; do not use stale orientation')
                gravity=rotation@gravity_from_rpy_deg(snapshot['sensor_angles_deg'])
                pitch=float(np.degrees(np.arctan2(gravity[0],np.hypot(gravity[1],gravity[2]))))
                target,neck_log=neck.apply(k,pitch,target,start,expected)
            guard.allowed=target
            try:
                bus.sync_write(42,2,[(i,target[i].to_bytes(2,'little')) for i in sorted(IDS)])
                guard.raw.flush()
            except serial.SerialTimeoutException as exc:
                confirm_position_write(bus,target,k,out['ambiguous_write_events'],exc)
            stamp=time.monotonic()
            out['events'].append(dict(frame=k,phase=frame['phase'],source_frame=frame['source_frame'],
                sent_targets=target,state_before_command=state,t_s=stamp-epoch,
                source_interval_s=frame['interval_s'],
                actual_interval_s=None if last is None else stamp-last,
                read_to_dispatch_ms=(stamp-begun)*1000,imu_snapshot=imu.snapshot(),neck_compensation=neck_log))
            if k in (0,150,250,350):print(json.dumps(dict(frame=k,phase=frame['phase'])),flush=True)
            expected=target;last=stamp
            if panel_progress is not None and (k%10==0 or k==399):
                panel_progress(dict(frame=k,total=400,phase=frame['phase'],elapsed_s=stamp-epoch,
                    pitch_deg=None if neck_log is None else neck_log['candidate_pitch_deg'],
                    compensation_deg=None if neck_log is None else neck_log['applied_back_offset_deg'],
                    neck_target=target[11],neck_actual=state[11]['pos'],
                    minimum_voltage=min(q['voltage'] for q in state.values())))
        out['after']=full()
        issued=[dict(target=e['sent_targets']) for e in out['events']]
        out['issued_prefix_target_sha256']=stream_sha(issued[:250])
        out['issued_motion_target_sha256']=stream_sha(issued[150:250])
        out['issued_unchanged_prefix_sha256']=stream_sha(issued[:250],unchanged_ids)
        if out['issued_unchanged_prefix_sha256']!=out['source_unchanged_prefix_sha256']:
            raise RuntimeError('Non-compensated target stream differs from pinned prefix')
        out['status']=('PREFIX_NECK_COMPENSATION_COMPLETE_R3_HELD_ONSITE_RESULT_PENDING' if neck is not None
                       else 'EXACT_PREFIX_COMPLETE_R3_HELD_ONSITE_RESULT_PENDING')
    except BaseException as exc:
        out.update(status='STOPPED_LAST_GOAL_HELD_NO_AUTO_RELEASE',failure=repr(exc),last_targets=expected)
        raise
    finally:
        out['imu_trace']=imu.stop();out['head_read_retries']=reader.events
        out['bus_stats']=dict(bus.stats);out['motion_target_packets']=guard.writes
        bus.close();out['serial_closed']=True
        prefix=('prefix_panel_compensation_' if panel_parameters is not None else
                'prefix_neck_half_compensation_' if neck is not None and neck.correction_scale==.5 else
                'prefix_neck8_compensation_' if neck is not None else 'exact_prefix_replay_')
        path=root/(prefix+str(time.time_ns())+'.json')
        path.write_text(json.dumps(out,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in out.items() if k not in ('events','before','after','imu_trace')}),flush=True)
        print('LOG '+str(path),flush=True)
    return out


if __name__=='__main__':main()
