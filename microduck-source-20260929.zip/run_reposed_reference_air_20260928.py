"""Finite reference replay. Default validates files, no serial.

Not live RL or validated walking. Ground uses a separate hash-bound two-switch
candidate and an explicit onsite-catch option. Only 8 direction-confirmed
leg joints are written; the other 7 must remain holding the new START.
"""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import statistics
import time

from sync_cycle_probe_20260927 import load_reference
from stationary_head_feedback_20260927 import MixedRateReader
from ordered_dispatch_clock_20260927 import OrderedDispatchClock
from imu_trace_20260927 import ImuTrace
from read_reposed_start_20260928 import PROFILE, PORT, decode

ACTIVE = (2,3,4,5,7,8,9,10)
SCOPE = 'SUPPORTED_AIR_ACHIEVED_REFERENCE_REPLAY_NOT_ONLINE_POLICY'
GROUND_SCOPE = 'SUPERVISED_TWO_SWITCH_REFERENCE_REPLAY_NOT_RL'
NOMINAL_SCOPE = 'FULL_START_NOMINAL_REFERENCE_OPERATOR_SUPERVISED_NOT_RL'
NOMINAL_SHA = 'ba8aed23ad6ff9a4b3963b50dc8bf31f000eaa7f28540884f41460b79733c31c'
SHORT_PULSE_SHA = '8be2cf9b35b32600f385539a85793266c991c13a58be4448e0adbb9fe57058c1'
PROFILE_SHA = '5d91667a42df93932f629eac0c856cca083005993085afbdc79ac7a27ed2343a'
PLAN_SHA = 'e015486441a8d79537319d329273706e084bdac7d72fbdea63691bbb8f98db98'
FASTER_PLAN_SHA = 'aa00bb09fb02dd9424534b2d326093cb924af3522721be350a6b674ce60da6d1'
BUS_SHA = '6523fcf728393f9f185edbc6760a538474b8a009e298f2444849b0c4558dad9a'
GROUND_SHA = '7182cf9faab558bfc5212de0188e3241a9566139e5ad38e97e1bbcfee1b44d8a'
AIR_RECEIPT_SHA = 'd06a99372de10d3e8c39d12af7356b2a44ae6b39ca381a89bbd82e584cb65b4f'


def load_plan(path, profile_path):
    cfg = json.loads(profile_path.read_text(encoding='utf8'))
    if hashlib.sha256(profile_path.read_bytes()).hexdigest() != PROFILE_SHA:
        raise ValueError('This runner is bound to the current saved START')
    plan = json.loads(path.read_text(encoding='utf8'))
    ground=plan['scope'] in (GROUND_SCOPE,NOMINAL_SCOPE)
    if (plan['scope'] not in (SCOPE,GROUND_SCOPE,NOMINAL_SCOPE) or plan['ground_execution_allowed'] is not ground
            or plan['execute_without_onsite_support_allowed'] is not False):
        raise ValueError('Supported-air plan required')
    if (plan['profile_sha256'] != PROFILE_SHA or plan['profile'] != PROFILE
            or plan['start_targets'] != cfg['targets']
            or plan['expected_offsets_raw'] != cfg['expected_offsets_raw']):
        raise ValueError('Stale START or EEPROM coordinate map')
    known = {5:(526,14,PLAN_SHA),3:(446,23,FASTER_PLAN_SHA)}
    if plan['scope']==NOMINAL_SCOPE:
        known={1:(580,70,SHORT_PULSE_SHA)} if plan.get('short_forward_pulse_s')==2.6 else {1:(571,70,NOMINAL_SHA)}
        if not plan.get('no_midstride_entry') or not plan.get('onsite_catch_required'):
            raise ValueError('Original-start finite candidate required')
    elif ground:
        if (plan.get('supported_air_receipt_sha256') != AIR_RECEIPT_SHA
                or not plan.get('air_observation_user_confirmed') or not plan.get('onsite_catch_required')):
            raise ValueError('Missing supported evidence')
        known={5:(426,14,GROUND_SHA)}
    if plan['source_slowdown'] not in known: raise ValueError('Unknown timing')
    frame_count, step_limit, expected_sha = known[plan['source_slowdown']]
    if (plan['active_ids'] != list(ACTIVE) or plan['frequency_hz'] != 50
            or len(plan['frames']) != frame_count):
        raise ValueError('Unreviewed trajectory contract')
    start = {i:cfg['targets'][str(i)] for i in range(1,16)}
    frames = []
    previous = start
    for row in plan['frames']:
        f = {int(k):v for k,v in row['target_raw'].items()}
        if set(f) != set(start): raise ValueError('Missing or extra IDs')
        for i,p in f.items():
            if (type(p) is not int or not 0 <= p <= 4095
                    or abs(p-start[i]) > 284 or abs(p-previous[i]) > step_limit):
                raise ValueError('Target outside supported candidate envelope')
            if i not in ACTIVE and p != start[i]: raise ValueError('Frozen joint changed')
        frames.append(f)
        previous = f
    if frames[0] != start or frames[-1] != start: raise ValueError('New START endpoints required')
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha:
        raise ValueError('Only the reviewed source-derived finite plan is accepted')
    return plan, cfg, frames


class AirSerial:
    """Allow reads and exactly one authorized 8-ID position packet per tick."""
    def __init__(self, raw, dynamic_neck=False):
        self.raw = raw
        self.allowed = None
        self.sync_writes = 0
        self.active=ACTIVE+(11,) if dynamic_neck else ACTIVE
        self.dynamic_neck=dynamic_neck
        self.last_neck=2817
    def write(self, packet):
        if (len(packet) < 6 or packet[:2] != b'\xff\xff'
                or len(packet) != packet[3]+4 or sum(packet[2:])%256 != 255):
            raise ValueError('Malformed transmit')
        sid, op, args = packet[2], packet[4], packet[5:-1]
        read = op == 2 and 1 <= sid <= 15 and args in (bytes([0,66]),bytes([40,26]))
        syncread = op == 0x82 and sid == 254 and args == bytes([40,26]+list(range(1,11)))
        if not (read or syncread):
            if self.allowed is None: raise ValueError('Unauthorized write')
            wanted = bytes([42,2])+b''.join(bytes([i,self.allowed[i]&255,self.allowed[i]>>8]) for i in self.active)
            if op != 0x83 or sid != 254 or args != wanted:
                raise ValueError('Only the pending 8-ID target packet may be sent')
            if self.dynamic_neck:
                if not 2749<=self.allowed[11]<=2817 or abs(self.allowed[11]-self.last_neck)>6:
                    raise ValueError('Neck total8deg/slew bound exceeded')
                self.last_neck=self.allowed[11]
            self.allowed = None
            self.sync_writes += 1
        count = self.raw.write(packet)
        if count != len(packet): raise IOError('Partial serial transmit')
        return count
    def __getattr__(self, key): return getattr(self.raw,key)


def execute(root, plan, cfg, frames, plan_path, read_only=False, settle_transient=False, operator_supervised=False, on_ground=False, dynamic_neck=False, ankle_feedback=False):
    import serial
    cls, source_sha = load_reference(root/'reference_feetech.py')
    if source_sha != BUS_SHA: raise ValueError('Unreviewed bus implementation')
    start = frames[0]
    offsets = {int(k):v for k,v in cfg['expected_offsets_raw'].items()}
    result = dict(status='PREFLIGHT', scope=plan['scope'], events=[],
                  profile_sha256=plan.get('effective_profile_sha256',PROFILE_SHA),
                  effective_profile=plan.get('effective_profile',PROFILE),
                  plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                  reference_bus_sha256=source_sha, source_action_is_online_policy=False,
                  read_only=read_only,
                  operator_supervised_telemetry=operator_supervised,
                  physical_trial_context='ground_onsite_catch' if on_ground else 'supported_air' if not read_only else 'read_only',
                  low_voltage_and_tracking_are_log_only=operator_supervised,
                  temporary_neck11_target=plan.get('temporary_neck11_target'),
                  recovery_of=plan.get('recovery_of'),
                  configuration_writes=0, torque_writes=0, fixed_ids=[1,6,11,12,13,14,15])
    result['special_trial']=plan.get('special_trial')
    result['source_time_scale']=plan.get('source_time_scale',1)
    if ankle_feedback:
        if dynamic_neck or not operator_supervised:raise ValueError('Separate R2 ankle feedback candidate required')
        result['ankle_control_contract']=dict(max_correction_deg=4,kp=.6,kd_seconds=.05,
            slew_deg_s=30,support=('both ankles; contact state not estimated' if plan.get('ankle_support_policy')=='both' else 'upstream predicted contact; not foot sensor'),
            imu_used_for_ankle_control=True)
    if dynamic_neck:
        if not operator_supervised or start[11]!=2817:raise ValueError('Dynamic neck requires explicit back2 base')
        result['fixed_ids']=[1,6,12,13,14,15]
        result['neck_control_contract']=dict(total_back_limit_deg=8,base_raw=2817,min_raw=2749,
            kp=.5,kd_seconds=.04,slew_deg_s=12,reference='median last50 preparation samples',
            imu_used_for_neck_control=True,not_rl=True)
    def cancel(*_): raise RuntimeError('Interrupted: retain last transmitted target, no torque-off')
    signal.signal(signal.SIGINT,cancel)
    signal.signal(signal.SIGTERM,cancel)
    imu = ImuTrace()
    raw = serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True)
    guard = AirSerial(raw,dynamic_neck)
    bus = cls(PORT,ser=guard)
    expected = dict(start)
    settler=None
    if settle_transient:
        if plan['scope']!=GROUND_SCOPE or read_only:raise ValueError('Settling only reviewed for ground two')
        from reposed_tracking_settle_20260928 import BoundedReferenceSettle
        settler=BoundedReferenceSettle(plan['max_increment_counts'])
        result['transient_hold_contract']=dict(advance_error_counts=35,
            max_transient_error_counts=settler.cap,deadline_ms=80,total_hold_ticks=20)
    def full_check():
        state = {}
        for i in start:
            error, data = bus.read(i,0,66)
            q = decode(data)
            q['host_received_mono_s'] = time.monotonic()
            status_mask=~1 if operator_supervised else 255
            if ((error & status_mask) or q['id'] != i or q['mode'] != 4 or q['offset'] != offsets[i]
                    or q['torque'] != 1 or q['target'] != expected[i] or (q['error'] & status_mask)
                    or not 0 < q['voltage'] <= 8.4
                    or not 0 <= q['pos'] <= 4095
                    or (not operator_supervised and (q['voltage']<4 or q['temp']>55 or abs(q['pos']-expected[i])>35))):
                raise RuntimeError('Full state mismatch '+str(q))
            state[i] = q
        return state
    try:
        try:imu.start()
        except Exception as exc:
            result['imu_start_observation']=repr(exc)
            if not operator_supervised:raise
        initial_time = time.monotonic()
        result['before'] = full_check()
        reader = MixedRateReader(bus,start,result['before'],initial_time)
        if operator_supervised:
            from operator_supervised_feedback_20260928 import OperatorSupervisedReader
            reader=OperatorSupervisedReader(bus,start,result['before'],dynamic_neck=dynamic_neck)
        # Each head was read at a different time. Use its actual receive time,
        # not the beginning of a 15-servo sweep, for the startup cache age.
        reader.stamps = {i:result['before'][i]['host_received_mono_s'] for i in reader.stamps}
        timer = OrderedDispatchClock()
        if operator_supervised:
            from operator_supervised_feedback_20260928 import OperatorDispatchClock
            timer=OperatorDispatchClock()
        epoch = time.monotonic()
        sequence = [dict(start) for _ in range(100)] if read_only else frames
        k=0;cycle=0;last_source=None;neck_controller=None;reference_samples=[]
        ankle_controller=None;ankle_reference=[];ankle_active=False
        while k<len(sequence):
            frame=dict(sequence[k])
            begun = timer.before_read()
            state, freshness = reader.read(cycle,expected,defer_leg_tracking=settler is not None)
            inertial = imu.snapshot()
            if (not inertial or inertial['error'] or inertial['host_age_ms'] > 150) and not operator_supervised:
                raise RuntimeError('IMU stream lost; retain last target')
            if time.monotonic()-epoch > (max(30,len(frames)*.02*3) if operator_supervised else len(frames)*.02+3):
                raise RuntimeError('Finite trial time budget exceeded')
            advance=True
            if settler:frame,advance=settler.choose(frame,expected,state,time.monotonic())
            source=plan['frames'][k]['provenance'] if advance else last_source
            neck_observation=None
            ankle_observation=None
            if dynamic_neck:
                from neck_pitch_compensation_20260928 import NeckPitchCompensation,feedback_snapshot
                now=time.monotonic()
                angles,gyro,age,imu_error=feedback_snapshot(imu,now)
                if k<150:
                    if angles is not None and age<=100 and not imu_error:
                        reference_samples.append(float(angles[1]))
                    neck_observation=dict(mode='COLLECT_STANDING_REFERENCE',samples=len(reference_samples))
                else:
                    if neck_controller is None and len(reference_samples)>=25:
                        neck_controller=NeckPitchCompensation(statistics.median(reference_samples[-50:]))
                    if neck_controller:
                        frame[11],neck_observation=neck_controller.update(now,angles,gyro,age,imu_error)
                    else:
                        frame[11]=expected[11]
                        neck_observation=dict(mode='NO_IMU_REFERENCE_HOLD_NECK_GAIT_CONTINUES')
            if ankle_feedback:
                from ankle_pitch_compensation_20260928 import AnklePitchCompensation
                from neck_pitch_compensation_20260928 import feedback_snapshot
                now=time.monotonic();angles,gyro,age,imu_error=feedback_snapshot(imu,now)
                if k<150:
                    if angles is not None and age<=100 and not imu_error:ankle_reference.append(float(angles[1]))
                    ankle_observation=dict(mode='COLLECT_R2_PITCH_REFERENCE',samples=len(ankle_reference))
                else:
                    if ankle_controller is None and len(ankle_reference)>=25:
                        ankle_controller=AnklePitchCompensation(statistics.median(ankle_reference[-50:]))
                    if source and source.get('source_t_s',0)>=2:ankle_active=True
                    contacts=source.get('reference_contacts') if source else [True,True]
                    if plan.get('ankle_support_policy')=='both':contacts=[True,True]
                    if ankle_controller:
                        ankle_offsets,ankle_observation=ankle_controller.update(now,angles,gyro,age,contacts,ankle_active,imu_error)
                        ankle_observation['support_selection']=plan.get('ankle_support_policy','reference_contact')
                        if any(abs(v)>46 for v in ankle_offsets.values()):raise ValueError('Ankle correction outside reviewed4deg')
                        for i,v in ankle_offsets.items():frame[i]+=v
                        if any(not 0<=p<=4095 for p in frame.values()):raise ValueError('Encoder boundary')
                    else:ankle_observation=dict(mode='NO_REFERENCE_NO_ANKLE_CORRECTION')
            stamp = timer.before_dispatch(begun)
            if not read_only:
                guard.allowed = frame
                bus.sync_write(42,2,[(i,frame[i].to_bytes(2,'little')) for i in guard.active])
                raw.flush()
                expected = dict(frame)
            result['events'].append(dict(frame=k,cycle=cycle,held_previous_target=not advance,t=time.monotonic()-epoch,
                state_before_command=state,feedback_freshness=freshness,
                next_command=frame,source=source,
                stage=plan['frames'][k]['stage'],imu=inertial,neck_control=neck_observation,
                ankle_control=ankle_observation,timing=stamp))
            if k == 0 or plan['frames'][k]['stage'] != plan['frames'][k-1]['stage']:
                print(json.dumps(dict(frame=k,stage=plan['frames'][k]['stage'])),flush=True)
            last_source=source
            if advance:k+=1
            cycle+=1
        result['after'] = full_check()
        if dynamic_neck:result['neck_final_target_raw']=expected[11]
        if ankle_feedback:result['final_ankle_targets']={i:expected[i] for i in (5,10)}
        result['status'] = ('CURRENT_START_TIMING_PASS_NO_MOTION' if read_only else
                            'SUPPORTED_PREFIX_REVERSED_NEW_START_HELD' if plan.get('recovery_of') else
                            'FINITE_GROUND_COMMANDS_COMPLETE_ONSITE_OUTCOME_PENDING' if on_ground else
                            'SUPPORTED_REFERENCE_FINISHED_NEW_START_HELD_NOT_GROUND_VERIFIED')
    except BaseException as exc:
        result.update(status='STOPPED_KEEP_LAST_TARGET_NO_AUTO_RELEASE',failure=repr(exc),last_command=expected)
        raise
    finally:
        result['imu_trace'] = imu.stop()
        if dynamic_neck:
            result['imu_trace']['mode']='SENSOR_TRACE_USED_BY_BOUNDED_NECK_CONTROLLER'
        if ankle_feedback:result['imu_trace']['mode']='SENSOR_TRACE_USED_BY_BOUNDED_STANCE_ANKLE_CONTROLLER'
        result['bus_stats'] = dict(bus.stats)
        result['sync_target_packets'] = guard.sync_writes
        if settler:result['settling']=dict(hold_ticks=settler.holds,max_hold_ms=settler.max_hold_ms)
        bus.close()
        result['serial_closed'] = True
        output = root/('reposed_reference_air_'+str(time.time_ns())+'.json')
        output.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('events','imu_trace','before','after')}),flush=True)
        print('LOG '+str(output),flush=True)
    return result,output


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--plan',type=Path,required=True)
    mode=cli.add_mutually_exclusive_group()
    mode.add_argument('--execute-supported-air',action='store_true')
    mode.add_argument('--read-only-timing',action='store_true')
    mode.add_argument('--recover-supported-air-log',type=Path)
    mode.add_argument('--execute-ground-with-onsite-catch',action='store_true')
    cli.add_argument('--settle-transient-leg-lag',action='store_true')
    cli.add_argument('--operator-supervised-telemetry',action='store_true',
                     help='Explicit user-authorized finite mode: voltage dip and position lag are logged, not aborts')
    cli.add_argument('--neck-back2',action='store_true',help='Hold explicit temporary neck11=2817; original START file unchanged')
    cli.add_argument('--dynamic-neck8',action='store_true',help='IMU-driven neck11 back2..total-back8 limited feedback')
    cli.add_argument('--head-retaught-r2',action='store_true',help='Hold the exact user-retaught R2 head pose; no old neck bias')
    cli.add_argument('--head-roll-r3',action='store_true',help='Hold exact roll14=957 R3 pose; no pitch changes')
    args = cli.parse_args()
    root = Path(__file__).resolve().parent
    plan,cfg,frames = load_plan(args.plan,root/PROFILE)
    if args.head_retaught_r2 and args.head_roll_r3:raise ValueError('Choose R2 or R3, not both')
    if args.head_retaught_r2 or args.head_roll_r3:
        if args.neck_back2 or args.dynamic_neck8 or args.recover_supported_air_log:
            raise ValueError('R2 cannot combine with old neck/recovery profiles')
        if plan['scope']!=NOMINAL_SCOPE or not args.operator_supervised_telemetry:
            raise ValueError('R2 selected for supervised nominal reference only')
        from head_retaught_r2_profile_20260928 import load_r2,retarget_fixed_head,NAME,SHA
        if args.head_roll_r3:
            from head_retaught_r2_profile_20260928 import load_r3_roll14,R3_NAME,R3_SHA
            cfg=load_r3_roll14(root,cfg);profile_name,profile_sha=R3_NAME,R3_SHA
        else:cfg=load_r2(root,cfg);profile_name,profile_sha=NAME,SHA
        frames=retarget_fixed_head(frames,cfg)
        plan=dict(plan,effective_profile=profile_name,effective_profile_sha256=profile_sha)
    if args.dynamic_neck8 and (not args.neck_back2 or not args.operator_supervised_telemetry or args.settle_transient_leg_lag):
        raise ValueError('Dynamic neck8 needs explicit back2 + operator mode; no old lag holds')
    if args.neck_back2:
        if plan['scope']!=NOMINAL_SCOPE or not args.operator_supervised_telemetry:
            raise ValueError('Temporary neck compensation only for nominal operator trial')
        if any(f[11]!=2840 for f in frames):raise ValueError('Unexpected neck base')
        for f in frames:f[11]=2817
        plan=dict(plan,temporary_neck11_target=2817,temporary_neck_delta_counts=-23)
    if args.settle_transient_leg_lag and not args.execute_ground_with_onsite_catch:
        raise ValueError('Settling requires explicit ground two execution')
    if args.operator_supervised_telemetry and (args.settle_transient_leg_lag or args.recover_supported_air_log):
        raise ValueError('Do not combine telemetry-only mode with old lag holds/prefix recovery')
    if plan['scope']==NOMINAL_SCOPE and (args.execute_supported_air or args.execute_ground_with_onsite_catch) and not args.operator_supervised_telemetry:
        raise ValueError('Nominal candidate requires explicitly authorized telemetry-only mode')
    if args.execute_supported_air and plan['scope'] not in (SCOPE,NOMINAL_SCOPE):raise ValueError('Air flag cannot run ground-only candidate')
    if args.execute_ground_with_onsite_catch and plan['scope'] not in (GROUND_SCOPE,NOMINAL_SCOPE):raise ValueError('Ground flag cannot run air-only candidate')
    if args.recover_supported_air_log and plan['scope']!=SCOPE:raise ValueError('Supported prefix recovery only')
    if args.execute_ground_with_onsite_catch and plan['scope']==GROUND_SCOPE:
        evidence=root/plan['supported_air_receipt']
        if hashlib.sha256(evidence.read_bytes()).hexdigest()!=AIR_RECEIPT_SHA:raise ValueError('Air receipt missing or changed')
    if args.recover_supported_air_log:
        old=json.loads(args.recover_supported_air_log.read_text(encoding='utf8'))
        if (old.get('status') != 'STOPPED_KEEP_LAST_TARGET_NO_AUTO_RELEASE'
                or old.get('read_only') is not False or old.get('scope') != SCOPE
                or old.get('profile_sha256') != PROFILE_SHA or old.get('recovery_of')
                or old.get('plan_sha256') != hashlib.sha256(args.plan.read_bytes()).hexdigest()
                or any(old['bus_stats'][k] for k in ('timeout','bad_checksum','bad_id'))):
            raise ValueError('Recovery requires matching finite air receipt with intact communication')
        count=old['sync_target_packets']
        if not 1 <= count <= len(frames) or len(old['events']) != count:
            raise ValueError('Unknown dispatched prefix')
        for k,e in enumerate(old['events']):
            if e['frame'] != k or {int(i):p for i,p in e['next_command'].items()} != frames[k]:
                raise ValueError('Dispatched prefix differs from plan')
        if {int(i):p for i,p in old['last_command'].items()} != frames[count-1]:
            raise ValueError('Last command differs from receipt')
        reverse=list(reversed(frames[:count]))
        # Remove the duplicated 3-second preparation hold; retain 0.5s START.
        while len(reverse)>1 and reverse[-1] == reverse[-2]:reverse.pop()
        reverse.extend([dict(frames[0]) for _ in range(25)])
        plan=dict(plan,recovery_of=args.recover_supported_air_log.name,
                  frames=[dict(stage='SUPPORTED_REVERSE_EXECUTED_PREFIX',provenance=None) for _ in reverse])
        frames=reverse
    print(json.dumps(dict(status='REFERENCE_PLAN_VALID',scope=plan['scope'],frames=len(frames),seconds=len(frames)*.02,
                         execute=bool(args.execute_supported_air or args.execute_ground_with_onsite_catch or args.recover_supported_air_log))),flush=True)
    if args.execute_supported_air or args.read_only_timing or args.recover_supported_air_log or args.execute_ground_with_onsite_catch:
        execute(root,plan,cfg,frames,args.plan,read_only=args.read_only_timing,
                settle_transient=args.settle_transient_leg_lag,
                operator_supervised=args.operator_supervised_telemetry,
                on_ground=args.execute_ground_with_onsite_catch,dynamic_neck=args.dynamic_neck8)


if __name__ == '__main__': main()
