"""User-authorized finite trials: low-voltage/position lag are telemetry.

This changes HOST experimental abort policy, not firmware protections or the
vendor operating specification. The operator provides physical catch/support.
Communication, actual servo faults, disabled/reset state, overvoltage,
unexpected targets and corrupt positions remain faults. Temperature is logged;
the servo's own temperature fault still follows the actual-fault path.
"""
import time


def decode_and_check(sid,error,data,origin,expected):
    def b(a):return data[a-origin]
    def w(a):return b(a)+256*b(a+1)
    raw=w(56)
    state=dict(torque=b(40),target=w(42),pos=-(raw&32767) if raw&32768 else raw,
               voltage=b(62)/10,temp=b(63),error=b(65))
    # Bit0 is the manufacturer's voltage status. Under-voltage alone is the
    # requested log-only observation, not a second hidden abort path.
    if (error & ~1) or (state['error'] & ~1) or state['torque']!=1 or state['target']!=expected[sid]:
        raise RuntimeError('Servo fault/reset/target mismatch '+str((sid,state)))
    if not 0<=state['pos']<=4095 or not 0<state['voltage']<=8.4:
        raise RuntimeError('Invalid feedback/overvoltage '+str((sid,state)))
    # Deliberately NO voltage >=4 gate and NO position-error abort gate.
    state['tracking_error_counts']=state['pos']-state['target']
    state['low_voltage_observation']=state['voltage']<4
    state['voltage_status_observation']=bool((error|state['error'])&1)
    state['ordinary_lag_observation']=abs(state['tracking_error_counts'])>35
    state['temperature_observation']=state['temp']>55
    return state


class OperatorSupervisedReader:
    def __init__(self,bus,baseline,initial,dynamic_neck=False):
        self.bus=bus;self.baseline=dict(baseline)
        self.dynamic_neck=dynamic_neck
        self.head={i:dict(initial[i]) for i in range(11,16)}
        self.stamps={i:initial[i]['host_received_mono_s'] for i in self.head}
    def read(self,cycle,expected,defer_leg_tracking=False):
        fixed=(12,13,14,15) if self.dynamic_neck else tuple(self.head)
        if any(expected[i]!=self.baseline[i] for i in fixed):raise RuntimeError('Fixed head target changed')
        rows=self.bus.sync_read(list(range(1,11)),40,26)
        if set(rows)!=set(range(1,11)) or any(x is None for x in rows.values()):
            raise RuntimeError('Incomplete leg communication')
        state={i:decode_and_check(i,*rows[i],40,expected) for i in rows}
        h=12+cycle%4 if self.dynamic_neck else 11+cycle%5
        self.head[h]=decode_and_check(h,*self.bus.read(h,40,26),40,expected)
        self.stamps[h]=time.monotonic()
        ages={i:(time.monotonic()-t)*1000 for i,t in self.stamps.items()}
        # If scheduling made another cached head old, refresh that head rather
        # than declaring a healthy, stationary robot failed due to cache age.
        fresh=[*range(1,11),h]
        if self.dynamic_neck:
            self.head[11]=decode_and_check(11,*self.bus.read(11,40,26),40,expected)
            self.stamps[11]=time.monotonic();fresh.append(11)
        for i in self.head:
            if ages[i]>120:
                self.head[i]=decode_and_check(i,*self.bus.read(i,40,26),40,expected)
                self.stamps[i]=time.monotonic();fresh.append(i)
        state.update(self.head)
        return state,dict(fresh_ids=fresh,head_host_read_age_ms={i:(time.monotonic()-t)*1000 for i,t in self.stamps.items()},
            nominal_leg_hz=50,nominal_per_head_hz=10,
            low_voltage_ids=[i for i,s in state.items() if s.get('low_voltage_observation')],
            tracking_warning_ids=[i for i,s in state.items() if s.get('ordinary_lag_observation')])


class OperatorDispatchClock:
    """No catch-up bursts; timing overruns are recorded, not a midstep stop."""
    def __init__(self):self.last_dispatch=None
    def before_read(self):
        if self.last_dispatch is not None:time.sleep(max(0,self.last_dispatch+.006-time.monotonic()))
        return time.monotonic()
    def before_dispatch(self,read_begun):
        read_ms=(time.monotonic()-read_begun)*1000
        if self.last_dispatch is not None:time.sleep(max(0,self.last_dispatch+.02-time.monotonic()))
        now=time.monotonic()
        interval=None if self.last_dispatch is None else (now-self.last_dispatch)*1000
        self.last_dispatch=now
        return dict(dispatch_mono_s=now,dispatch_interval_ms=interval,read_ms=read_ms,
                    read_soft_budget_exceeded=read_ms>18,timing_observation_only=True)
