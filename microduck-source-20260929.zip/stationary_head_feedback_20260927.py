"""Mixed-rate feedback: leg chain every tick, one stationary head ID per tick.

At 50Hz ticks this is 50Hz for IDs1..10 and 10Hz each for11..15. Age metadata
means host-read age, not firmware sensor-sampling age. No writes in this class.
"""
import time
from timed_air_replay_20260927 import check_state,PositionTrackingLag

HEAD=(11,12,13,14,15)


class MixedRateReader:
    def __init__(self,bus,baseline,initial_state,initial_time,clock=time.monotonic):
        self.bus=bus;self.baseline=dict(baseline);self.clock=clock
        self.head={i:dict(initial_state[i]) for i in HEAD}
        # Timestamp before preflight conservatively overestimates initial age.
        self.stamps={i:initial_time for i in HEAD}

    def read(self,cycle,expected,defer_leg_tracking=False):
        if any(expected[i]!=self.baseline[i] for i in HEAD):
            raise RuntimeError('10Hz head reader only supports fixed head targets')
        received=self.bus.sync_read(list(range(1,11)),40,26)
        if set(received)!=set(range(1,11)) or any(v is None for v in received.values()):
            raise RuntimeError('Incomplete fresh leg feedback')
        states={};lagging=[]
        for i in range(1,11):
            try:states[i]=check_state(i,*received[i],40,expected)
            except PositionTrackingLag as exc:
                if not defer_leg_tracking:raise
                states[i]=exc.state;lagging.append(i)
        head_id=HEAD[cycle%len(HEAD)]
        self.head[head_id]=check_state(head_id,*self.bus.read(head_id,40,26),40,expected)
        self.stamps[head_id]=self.clock()
        now=self.clock()
        ages={i:(now-self.stamps[i])*1000 for i in HEAD}
        if max(ages.values())>120:
            raise RuntimeError('Stationary head feedback older than 120ms')
        states.update(self.head)
        return states,dict(fresh_ids=list(range(1,11))+[head_id],head_host_read_age_ms=ages,
                           nominal_leg_hz=50,nominal_per_head_hz=10,lagging_leg_ids=lagging)
