"""Finite original-policy preview, with separately explicit ground experiment.

Uses a documented visual-STAND mounting hypothesis, not measured extrinsics.
All 14 directions confirmed, original scale=1; explicit envelope/slew clipping
is logged and means this is NOT unmodified-policy sim2real acceptance.
Default no hardware. Ground experiment additionally requires the exact passed
.45 supported-air receipt and new onsite catch confirmation. It is NOT stable
walking acceptance or a promotion of the candidate IMU into measured extrinsics.
No torque/EEPROM writes. Mouth remains at saved R3.
"""
import argparse
import hashlib
import json
import signal
import time
from pathlib import Path
import numpy as np
from ft_policy_adapter_20260928 import (IDS,OriginalPolicy,ShadowMapping,
    gravity_from_rpy_deg,rotate_sensor_vectors)
from head_retaught_r2_profile_20260928 import load_r3_roll14,R3_NAME,R3_SHA
from run_reposed_reference_air_20260928 import PROFILE,PORT,BUS_SHA
from sync_cycle_probe_20260927 import load_reference
from read_reposed_start_20260928 import decode
from operator_supervised_feedback_20260928 import decode_and_check
from imu_trace_20260927 import ImuTrace
from policy_takeover_20260929 import blend_takeover
from policy_mode_transition_20260929 import PolicyModeTransition
from bounded_head_read_20260929 import BoundedHeadRead
from confirm_position_write_20260929 import confirm_position_write

CAP_DEG={1:10,2:10,3:15,4:22,5:20,6:10,7:10,8:15,9:22,10:15,11:10,12:10,13:10,14:10}
SLEW_COUNTS={i:(5 if i in (1,6,11,12,13,14) else 18) for i in IDS}
PASSED_AIR='live_policy_air_preview_1790651608000025186.json'
PASSED_AIR_SHA='73764666e2c9bb7b76f42ebb64d7e111382fd942bce9774271339884acb41b1c'


def schedule(ground=False,takeover_check=False,prefix_check=False):
    # Ground uses the same controller/envelope with a 2.6s forward pulse,
    # followed by full 2s standing policy and 2s R3 blend, not a mid-step cut.
    if takeover_check and prefix_check:raise ValueError('Separate diagnostic modes')
    if takeover_check or prefix_check:
        if not ground:raise ValueError('Takeover check is an explicit ground diagnostic')
        return dict(prepare_end=150,stand_end=250,forward_end=250,
                    policy_end=250,return_end=350,total=400)
    forward_end=380 if ground else 450
    return dict(prepare_end=150,stand_end=250,forward_end=forward_end,
                policy_end=forward_end+100,return_end=forward_end+200,total=forward_end+250)


def validate_ground_evidence(root,cfg):
    path=root/PASSED_AIR
    if not path.exists():path=root/'calibration_20260926'/PASSED_AIR
    if hashlib.sha256(path.read_bytes()).hexdigest()!=PASSED_AIR_SHA:raise ValueError('Air evidence changed')
    record=json.loads(path.read_text(encoding='utf8'))
    if (record['position_error_gain']!=.45 or record['profile_sha256']!=R3_SHA
            or record['status']!='BOUNDED_AIR_POLICY_COMPLETE_R3_HELD_NOT_GROUND_PASSED'
            or len(record['events'])!=700):raise ValueError('Air evidence not completed')
    if any(record['after'][i]['torque']!=1 or record['after'][i]['target']!=v for i,v in cfg['targets'].items()):
        raise ValueError('Air did not finish at exact enabled R3')
    return PASSED_AIR_SHA


def match_position_error(raw,actual,gain):
    """Explicit preview experiment, not a change to the actor's action scale.

    The original action stays in last_action. Only physical position error is
    reduced about current actual, before the unchanged preview caps/slew.
    .45 is an offline candidate, NOT identified HD dynamics or ground release.
    """
    if gain not in (1.,.45):raise ValueError('Only declared preview gains allowed')
    if set(raw)!=set(IDS) or not set(IDS).issubset(actual):raise ValueError('Missing axis')
    if any(type(raw[i]) is not int or type(actual[i]) is not int for i in IDS):
        raise ValueError('Integer positions required')
    if any(not 0<=actual[i]<=4095 for i in IDS):raise ValueError('Actual coordinate outside encoder')
    return {i:round(actual[i]+gain*(raw[i]-actual[i])) for i in IDS}


def bounded_targets(raw,start,previous):
    if set(raw)!=set(IDS) or any(type(v) is not int for v in raw.values()):
        raise ValueError('Complete 14-axis integer conversion required')
    target=dict(start);clipped=[]
    for sid in IDS:
        cap=round(CAP_DEG[sid]*4096/360)
        limited=max(start[sid]-cap,min(start[sid]+cap,raw[sid]))
        value=max(previous[sid]-SLEW_COUNTS[sid],min(previous[sid]+SLEW_COUNTS[sid],limited))
        if not 0<=value<=4095:raise ValueError('Encoder range')
        target[sid]=value
        if value!=raw[sid]:clipped.append(dict(id=sid,requested_raw_target=raw[sid],sent=value,
            amplitude_clipped=limited!=raw[sid],slew_clipped=value!=limited))
    return target,clipped


class AirPolicySerial:
    def __init__(self,raw,start):
        self.raw=raw;self.start=start;self.last=dict(start);self.allowed=None;self.writes=0
    def write(self,p):
        if len(p)<6 or p[:2]!=b'\xff\xff' or len(p)!=p[3]+4 or sum(p[2:])%256!=255:
            raise ValueError('Malformed packet')
        sid,op,args=p[2],p[4],p[5:-1]
        read=op==2 and 1<=sid<=15 and args in (bytes([0,66]),bytes([40,26]))
        sync=op==0x82 and sid==254 and args==bytes([40,26]+list(range(1,11)))
        if not (read or sync):
            f=self.allowed
            if f is None or f[15]!=self.start[15]:raise ValueError('No pending frame or mouth changed')
            for i in IDS:
                if abs(f[i]-self.start[i])>round(CAP_DEG[i]*4096/360) or abs(f[i]-self.last[i])>SLEW_COUNTS[i]:
                    raise ValueError('Preview amplitude/slew envelope')
            wanted=bytes([42,2])+b''.join(bytes([i,f[i]&255,f[i]>>8]) for i in sorted(IDS))
            if sid!=254 or op!=0x83 or args!=wanted:raise ValueError('Only bounded 14-axis target packet allowed')
            self.last=dict(f);self.allowed=None;self.writes+=1
        n=self.raw.write(p)
        if n!=len(p):raise IOError('Partial write')
        return n
    def __getattr__(self,k):return getattr(self.raw,k)


def prepare(root):
    cfg=load_r3_roll14(root,json.loads((root/PROFILE).read_text(encoding='utf8')))
    direction_path=root/'FT_POLICY_AXIS_DIRECTIONS_20260928.json'
    evidence=json.loads(direction_path.read_text(encoding='utf8'))
    mp=root/'visual_stand_mapping.json'
    if not mp.exists():mp=root/'sim2real_audit_20260928/reposed_start/visual_stand_mapping.json'
    mapping=ShadowMapping(json.loads(mp.read_text(encoding='utf8')),cfg,evidence)
    if mapping.unknown or mapping.sign[11]!=1 or mapping.sign[12]!=1:raise ValueError('Corrected full directions required')
    cp=root/'imu_mount_near_stand_candidate.json'
    if not cp.exists():cp=root/'sim2real_audit_20260928/reposed_start/imu_mount_near_stand_candidate.json'
    candidate=json.loads(cp.read_text(encoding='utf8'))
    if (candidate['profile_sha256']!=R3_SHA or candidate['ground_execution_allowed'] is not False
            or candidate['direction_evidence_sha256']!=hashlib.sha256(direction_path.read_bytes()).hexdigest()):
        raise ValueError('Stale reference hypothesis')
    rotation=np.array(candidate['body_from_sensor_rotation'])
    rotate_sensor_vectors([0,0,-1],[0,0,0],rotation)
    return cfg,mapping,candidate,rotation


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    modes=cli.add_mutually_exclusive_group()
    modes.add_argument('--execute-supported-air',action='store_true')
    modes.add_argument('--execute-ground-with-onsite-catch',action='store_true')
    modes.add_argument('--execute-ground-takeover-check',action='store_true')
    modes.add_argument('--plan-ground-takeover-check',action='store_true')
    modes.add_argument('--execute-ground-prefix-check',action='store_true',
        help='Keep exactly first 2s of original standing actor, then blend R3; no walking actor command.')
    modes.add_argument('--plan-ground-prefix-check',action='store_true')
    modes.add_argument('--plan-ground',action='store_true')
    cli.add_argument('--position-error-gain',type=float,choices=(1.,.45),default=1.)
    cli.add_argument('--takeover-seconds',type=float,choices=(0.,1.),default=0.)
    cli.add_argument('--actor-transition-seconds',type=float,choices=(0.,.6),default=0.)
    cli.add_argument('--head-read-retry',type=int,choices=(0,1),default=0)
    cli.add_argument('--confirm-ambiguous-write',action='store_true')
    args=cli.parse_args();root=Path(__file__).resolve().parent
    cfg,mapping,candidate,rotation=prepare(root);start={int(i):v for i,v in cfg['targets'].items()}
    takeover_check=args.execute_ground_takeover_check or args.plan_ground_takeover_check
    prefix_check=args.execute_ground_prefix_check or args.plan_ground_prefix_check
    ground=args.execute_ground_with_onsite_catch or args.plan_ground or takeover_check or prefix_check
    execute=(args.execute_supported_air or args.execute_ground_with_onsite_catch
             or args.execute_ground_takeover_check or args.execute_ground_prefix_check)
    sched=schedule(ground,takeover_check,prefix_check)
    if takeover_check and args.takeover_seconds!=1.:raise ValueError('Diagnostic requires explicit one-second takeover')
    if ground and not takeover_check and args.takeover_seconds:
        raise ValueError('Modified ground walk not released by a stand-only diagnostic')
    if ground and args.position_error_gain!=.45:raise ValueError('Ground candidate limited to tested .45 adapter')
    if args.actor_transition_seconds and (args.takeover_seconds or takeover_check or args.position_error_gain!=.45):
        raise ValueError('Actor transition is a separate .45 experiment, not combined with R3 takeover')
    evidence=validate_ground_evidence(root,cfg) if ground else None
    print(json.dumps(dict(status='BOUNDED_GROUND_EXPERIMENT_PLAN' if ground else 'BOUNDED_AIR_PREVIEW_PLAN',execute=execute,
        duration_s=sched['total']*.02,schedule_frames=sched,
        imu_hypothesis_not_measured=True,general_ground_release=False,onsite_experiment=ground,amplitude_caps_deg=CAP_DEG,
        position_error_gain=args.position_error_gain,takeover_seconds=args.takeover_seconds,
        actor_transition_seconds=args.actor_transition_seconds,
        head_read_retry=args.head_read_retry,
        confirm_ambiguous_write=args.confirm_ambiguous_write,
        prefix_check_only=prefix_check,walking_actor_command_planned=not (prefix_check or takeover_check),
        stand_takeover_check_only=takeover_check,firmware_gains_unchanged=True)),flush=True)
    if not execute:return
    policy=OriginalPolicy(root)
    if args.actor_transition_seconds:policy=PolicyModeTransition(policy,args.actor_transition_seconds)
    cls,sha=load_reference(root/'reference_feetech.py')
    if sha!=BUS_SHA:raise ValueError('Bus source changed')
    import serial
    guard=AirPolicySerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True),start)
    bus=cls(PORT,ser=guard);imu=ImuTrace();expected=dict(start)
    head_reader=(BoundedHeadRead(bus,cls.read.__globals__['BusTimeout'],serial.SerialTimeoutException)
                 if args.head_read_retry else None)
    result=dict(scope=('BOUNDED_LIVE_POLICY_GROUND_EXPERIMENT_REQUIRES_ONSITE_OBSERVATION' if ground
                else 'SUPPORTED_BOUNDED_LIVE_POLICY_PREVIEW_NOT_GROUND_VALIDATION'),profile=R3_NAME,
        preceding_air_receipt_sha256=evidence,general_ground_release=False,schedule_frames=sched,
        profile_sha256=R3_SHA,mount_candidate=candidate,applied_mount_hypothesis_for_this_preview=True,
        current_signs=mapping.sign,raw_action_scale=1.,explicit_amplitude_caps_deg=CAP_DEG,
        position_error_gain=args.position_error_gain,controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        takeover_seconds=args.takeover_seconds,stand_takeover_check_only=takeover_check,
        prefix_check_only=prefix_check,walking_actor_command_planned=not (prefix_check or takeover_check),
        actor_transition_seconds=args.actor_transition_seconds,
        actor_transition_source_sha256=hashlib.sha256((root/'policy_mode_transition_20260929.py').read_bytes()).hexdigest(),
        head_read_retry=args.head_read_retry,
        head_read_retry_source_sha256=hashlib.sha256((root/'bounded_head_read_20260929.py').read_bytes()).hexdigest(),
        confirm_ambiguous_write=args.confirm_ambiguous_write,ambiguous_write_events=[],
        confirm_write_source_sha256=hashlib.sha256((root/'confirm_position_write_20260929.py').read_bytes()).hexdigest(),
        takeover_source_sha256=hashlib.sha256((root/'policy_takeover_20260929.py').read_bytes()).hexdigest(),
        clipping_input='takeover_requested_raw_targets; raw policy/error adapter/temporary takeover cap IDs separately logged',
        explicit_slew_counts_per_tick=SLEW_COUNTS,observations_are_actual_feedback=True,
        torque_writes=0,configuration_writes=0,events=[],status='PREFLIGHT')
    def full():
        out={}
        for i in range(1,16):
            err,data=bus.read(i,0,66);q=decode(data);decode_and_check(i,err,data,0,expected)
            if q['id']!=i or q['mode']!=4 or q['offset']!=cfg['expected_offsets_raw'][str(i)]:raise ValueError('Coordinate/mode changed')
            out[i]=q
        return out
    def cancel(*_):raise RuntimeError('Interrupted: retain last targets; no auto release/reset')
    signal.signal(signal.SIGINT,cancel);signal.signal(signal.SIGTERM,cancel)
    try:
        result['before']=full();imu.start();epoch=time.monotonic();last_dispatch=None;return_from=None
        for k in range(sched['total']):
            begun=time.monotonic();rows=bus.sync_read(list(range(1,11)),40,26)
            leg_read_complete=time.monotonic()
            for i in range(11,16):rows[i]=head_reader.read(i,k) if head_reader is not None else bus.read(i,40,26)
            if set(rows)!=set(start) or any(v is None for v in rows.values()):raise RuntimeError('Incomplete control feedback')
            state={i:decode_and_check(i,*rows[i],40,expected) for i in rows};stamp=time.monotonic()
            # Preserve raw feedback without inventing a torque/current unit.
            for i,(_,data) in rows.items():
                state[i].update(speed_raw=data[18]+256*data[19],load_raw=data[20]+256*data[21])
            angles=imu.latest.get(0x53);gyro=imu.latest.get(0x52)
            if not angles or not gyro or imu.error:raise RuntimeError('Missing control IMU')
            age=max((stamp-r['mono_s'])*1000 for r in (angles,gyro))
            if age>150:raise RuntimeError('Stale IMU cannot supply control observation')
            q,qd,validity=mapping.coordinates({i:s['pos'] for i,s in state.items()},stamp)
            gravity,body_gyro=rotate_sensor_vectors(gravity_from_rpy_deg(angles['sensor_angles_deg']),
                np.radians(gyro['sensor_gyro_dps']),rotation)
            pred=None;clipped=[];raw=None;adapted=None;handover=None;alpha=None
            if k<sched['prepare_end']:
                phase='PREPARE_GROUND_ONSITE' if ground else 'PREPARE_SUPPORTED_AIR';target=dict(start)
            elif k<sched['policy_end']:
                phase='LIVE_STAND' if k<sched['stand_end'] or k>=sched['forward_end'] else 'LIVE_FORWARD'
                command=mapping.r3_head_command();command[0]=.25 if phase=='LIVE_FORWARD' else 0
                pred=policy.step(q,qd,body_gyro,gravity,command)
                raw=mapping.targets(pred['policy_target_rad'])['raw_unclipped_shadow']
                adapted=match_position_error(raw,{i:s['pos'] for i,s in state.items()},args.position_error_gain)
                handover,alpha=blend_takeover(adapted,start,CAP_DEG,
                    (k-sched['prepare_end'])*.02,args.takeover_seconds)
                target,clipped=bounded_targets(handover,start,expected)
            elif k<sched['return_end']:
                phase='GROUND_BLEND_R3' if ground else 'SUPPORTED_RETURN_R3'
                if return_from is None:return_from=dict(expected)
                u=(k-sched['policy_end']+1)/100;v=u*u*(3-2*u)
                target={i:round(return_from[i]+(start[i]-return_from[i])*v) for i in start}
            else:
                phase='FINAL_R3_HOLD';target=dict(start)
            work_done=time.monotonic()
            if last_dispatch is not None:time.sleep(max(0,last_dispatch+.02-time.monotonic()))
            if time.monotonic()-epoch>30:raise RuntimeError('Finite preview deadline')
            guard.allowed=target
            try:
                bus.sync_write(42,2,[(i,target[i].to_bytes(2,'little')) for i in sorted(IDS)])
                guard.raw.flush()
            except serial.SerialTimeoutException as exc:
                if not args.confirm_ambiguous_write:raise
                confirm_position_write(bus,target,k,result['ambiguous_write_events'],exc)
            dispatch=time.monotonic()
            result['events'].append(dict(frame=k,phase=phase,t_s=dispatch-epoch,state_before_command=state,
                q_approx_rad=q.tolist(),qdot_approx_rad_s=qd.tolist(),gravity_body_candidate=gravity.tolist(),
                sensor_rpy_deg=angles['sensor_angles_deg'],imu_age_ms=age,policy=pred,clipping=clipped,
                original_policy_raw_targets=raw,error_adapted_raw_targets=adapted,
                takeover_requested_raw_targets=handover,takeover_weight=alpha,
                takeover_cap_ids=([i for i in IDS if abs(adapted[i]-start[i])>round(CAP_DEG[i]*4096/360)]
                    if alpha is not None and alpha<1 else []),
                leg_feedback_batch_complete_t_s=leg_read_complete-epoch,
                all_feedback_complete_t_s=stamp-epoch,
                previous_dispatch_t_s=None if last_dispatch is None else last_dispatch-epoch,
                leg_feedback_age_at_dispatch_ms=(dispatch-leg_read_complete)*1000,
                sent_targets=target,read_and_compute_ms=(work_done-begun)*1000,
                dispatch_interval_ms=None if last_dispatch is None else (dispatch-last_dispatch)*1000))
            if k==0 or phase!=result['events'][-2]['phase']:print(json.dumps(dict(frame=k,phase=phase)),flush=True)
            expected=dict(target);last_dispatch=dispatch
        result['after']=full();result['status']=(
            'PREFIX_CHECK_COMPLETE_R3_HELD_ONSITE_RESULT_PENDING' if prefix_check else
            ('BOUNDED_GROUND_EXPERIMENT_COMPLETE_R3_HELD_ONSITE_RESULT_PENDING' if ground
             else 'BOUNDED_AIR_POLICY_COMPLETE_R3_HELD_NOT_GROUND_PASSED'))
    except BaseException as exc:
        result.update(status='STOPPED_LAST_GOAL_HELD_NO_AUTO_RELEASE',failure=repr(exc),last_targets=expected)
        raise
    finally:
        result['head_read_retries']=head_reader.events if head_reader is not None else []
        result['imu_trace']=imu.stop();result['bus_stats']=dict(bus.stats);result['motion_target_packets']=guard.writes
        bus.close();result['serial_closed']=True
        prefix=('prefix_stand_check_' if prefix_check else
                ('policy_takeover_check_' if takeover_check else
                 ('live_policy_ground_trial_' if ground else 'live_policy_air_preview_')))
        path=root/(prefix+str(time.time_ns())+'.json')
        path.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('events','before','after','imu_trace','mount_candidate')}),flush=True)
        print('LOG '+str(path),flush=True)


if __name__=='__main__':main()
