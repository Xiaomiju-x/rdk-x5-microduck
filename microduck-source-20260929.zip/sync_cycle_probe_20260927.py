"""Finite START-only timing probe using the author's FeetechBus.

No gait, calibration, torque changes, or arbitrary target interface. The serial
wrapper rejects all writes except an optional exact 15-ID START sync-write.
Default is plan-only; --read-only issues READ/SYNC_READ instructions only.
"""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import time

ROOT = Path(__file__).resolve().parent
PORT = '/dev/serial/by-id/SELECT_SERVO_ADAPTER'
START = dict(enumerate([1283,2048,1471,516,2047,389,1098,2104,2047,2047,2799,3687,259,972,2093], 1))
OFFSETS = {i: {5:1829,9:1908,10:1996}.get(i,0) for i in START}


def check_packet(data, allow_same_start=False):
    if len(data) < 6 or data[:2] != b'\xff\xff' or len(data) != data[3]+4 or sum(data[2:]) % 256 != 255:
        raise ValueError('Invalid transmit frame')
    sid, op, params = data[2], data[4], data[5:-1]
    if op == 2 and sid in START and params in (bytes([0,66]), bytes([31,35]), bytes([40,26])):
        return
    if op == 0x82 and sid == 254 and params in tuple(bytes([a,n]+ids) for a,n in ((31,35),(40,26)) for ids in (list(START),list(range(1,11)))):
        return
    wanted = bytes([42,2]) + b''.join(bytes([i,p & 255,p >> 8]) for i,p in START.items())
    if allow_same_start and sid == 254 and op == 0x83 and params == wanted:
        return
    raise ValueError('Command outside read-only/exact START hold scope')


class GuardedSerial:
    def __init__(self, serial_port, allow_same_start=False):
        self._serial = serial_port
        self._allow = allow_same_start
        self.tx = {'read':0, 'sync_read':0, 'same_start_write':0}
        self.last_rx = bytearray()

    def write(self, data):
        check_packet(data, self._allow)
        kind = {2:'read',0x82:'sync_read',0x83:'same_start_write'}[data[4]]
        self.tx[kind] += 1
        self.last_rx.clear()
        sent = self._serial.write(data)
        if sent != len(data):
            raise IOError('Partial transmit')
        return sent

    def read(self, count=1):
        data=self._serial.read(count)
        self.last_rx.extend(data)
        return data

    def __getattr__(self, key):
        return getattr(self._serial, key)


def decode_and_check(sid, error, data, first_address):
    def byte(addr):
        return data[addr-first_address]
    def word(addr):
        return byte(addr)+256*byte(addr+1)
    q = dict(torque=byte(40), target=word(42),
             pos=word(56), voltage=byte(62)/10, temp=byte(63), error=byte(65))
    if first_address == 0 and byte(5) != sid:
        raise RuntimeError('ID mismatch')
    if first_address <= 31:
        q.update(offset=word(31), mode=byte(33))
        if q['offset'] != OFFSETS[sid] or q['mode'] != 4:
            raise RuntimeError(f'ID{sid} coordinate/mode changed: {q}')
    if error or q['error']:
        raise RuntimeError(f'ID{sid} status error: {q}')
    if q['torque'] != 1 or q['target'] != START[sid] or not 0 <= q['pos'] <= 4095:
        raise RuntimeError(f'ID{sid} not holding START: {q}')
    if not 4.0 <= q['voltage'] <= 8.4 or q['temp'] > 55 or abs(q['pos']-q['target']) > 35:
        raise RuntimeError(f'ID{sid} health/tracking check: {q}')
    return q


def summarize(values):
    ordered = sorted(values)
    return dict(n=len(values), mean=statistics.mean(values), p50=statistics.median(values),
                p95=ordered[min(len(ordered)-1,int(.95*len(ordered)))], max=max(values))


def load_reference(path):
    source=path.read_bytes()
    text=source.decode('utf8')
    old="hexs(b'\\xff\\xff' + rest + body)"
    if text.count(old)!=1:
        raise RuntimeError('Reference syntax adapter no longer matches')
    text=text.replace(old,'hexs(bytes((255,255)) + rest + body)')
    reference={'__name__':'author_feetech','__file__':str(path)}
    exec(compile(text,str(path),'exec'),reference)
    return reference['FeetechBus'],hashlib.sha256(source).hexdigest()


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    mode = cli.add_mutually_exclusive_group()
    mode.add_argument('--read-only', action='store_true')
    mode.add_argument('--same-start-hold', action='store_true')
    cli.add_argument('--reference-path', type=Path, default=ROOT/'reference_feetech.py')
    cli.add_argument('--rounds', type=int, default=250)
    cli.add_argument('--block',choices=('full','runtime'),default='full')
    cli.add_argument('--transport',choices=('all-sync','legs-sync-head-read'),default='all-sync')
    args = cli.parse_args()
    if not args.read_only and not args.same_start_hold:
        print('PLAN_ONLY: no serial opened. Use --read-only first; --same-start-hold never changes targets.')
        return
    if not 25 <= args.rounds <= 500:
        raise ValueError('Bounded probe: 25..500 rounds')
    # Upstream uses Python 3.12's backslash-in-f-string syntax. X5 has 3.10.
    # Adapt only the trace formatting expression in memory; keep source intact.
    bus_class,reference_sha=load_reference(args.reference_path)
    import serial
    result = dict(scope='EXACT_START_TIMING_ONLY_NOT_WALKING', status='STARTING',
                  reference_sha256=reference_sha, frequency_hz=50,
                  compatibility_patch='Trace formatting: bytes((255,255)) for Python 3.10; no protocol edits',
                  mode='same-start-hold' if args.same_start_hold else 'read-only', records=[])
    result['block']=args.block
    result['transport']=args.transport
    raw = serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True)
    guarded = GuardedSerial(raw, args.same_start_hold)
    bus = bus_class(PORT, ser=guarded)
    def full_check():
        return {i:decode_and_check(i,*bus.read(i,0,66),0) for i in START}
    try:
        result['before'] = full_check()
        timings=[]
        for _ in range(10):
            begun=time.monotonic()
            full_check()
            timings.append(1000*(time.monotonic()-begun))
        result['sequential_full_read_ms'] = summarize(timings)
        epoch=time.monotonic()
        for k in range(args.rounds):
            scheduled=epoch+k*.02
            time.sleep(max(0,scheduled-time.monotonic()))
            begun=time.monotonic()
            address,count=(31,35) if args.block=='full' else (40,26)
            ids=list(START) if args.transport=='all-sync' else list(range(1,11))
            received=bus.sync_read(ids,address,count)
            if args.transport=='legs-sync-head-read':
                # ID12 checksum failures from the all-sync attempt are retained;
                # use ordinary verified reads for the stationary head chain.
                for i in range(11,16):
                    received[i]=bus.read(i,address,count)
            if set(received)!=set(START) or any(v is None for v in received.values()):
                result['failed_rx_hex']=guarded.last_rx.hex()
                raise RuntimeError('Incomplete SYNC_READ IDs: '+str([i for i,v in received.items() if v is None]))
            state={i:decode_and_check(i,*received[i],address) for i in START}
            # The just-read torque/offset/health must pass before every hold write.
            if args.same_start_hold:
                bus.sync_write(42,2,[(i,p.to_bytes(2,'little')) for i,p in START.items()])
                raw.flush()
            ended=time.monotonic()
            result['records'].append(dict(t=begun-epoch, work_ms=(ended-begun)*1000,
                                           start_lateness_ms=(begun-scheduled)*1000,state=state))
        result['after']=full_check()
        durations=[r['work_ms'] for r in result['records']]
        intervals=[1000*(b['t']-a['t']) for a,b in zip(result['records'],result['records'][1:])]
        result.update(status='PASS', work_ms=summarize(durations), interval_ms=summarize(intervals),
                      work_over_20ms=sum(v>20 for v in durations),
                      intervals_over_30ms=sum(v>30 for v in intervals))
    except BaseException as exc:
        result.update(status='FAILED_NO_RECOVERY_WRITES', failure=repr(exc))
        raise
    finally:
        result['transmits']=guarded.tx
        result['reference_stats']=dict(bus.stats)
        bus.close()
        output=ROOT/('sync_cycle_'+str(time.time_ns())+'.json')
        output.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('records','before','after','failed_rx_hex')}),flush=True)
        print('LOG '+str(output),flush=True)


if __name__ == '__main__':
    main()
