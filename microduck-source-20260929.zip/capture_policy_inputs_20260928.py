"""Finite live all-joint+IMU acquisition or ONNX shadow. NO motion write path.

GuardedSerial rejects WRITE/SYNC_WRITE/torque/configuration opcodes entirely.
Even if policy outputs are extreme they are recorded, never sent to hardware.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from sync_cycle_probe_20260927 import GuardedSerial,load_reference
from run_reposed_reference_air_20260928 import BUS_SHA,PROFILE,PORT
from head_retaught_r2_profile_20260928 import load_r3_roll14,R3_NAME,R3_SHA
from read_reposed_start_20260928 import decode
from operator_supervised_feedback_20260928 import decode_and_check
from imu_trace_20260927 import ImuTrace
from ft_policy_adapter_20260928 import ShadowMapping,OriginalPolicy,gravity_from_rpy_deg


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--read-only-shadow',action='store_true')
    parser.add_argument('--frames',type=int,default=250)
    parser.add_argument('--policy-dir',type=Path)
    args=parser.parse_args()
    if not 25<=args.frames<=500:raise ValueError('Finite 25..500 samples')
    if not args.read_only_shadow:
        print('PLAN_ONLY_NO_SERIAL: --read-only-shadow collects inputs; optional --policy-dir also runs CPU policy without writes.')
        return
    root=Path(__file__).resolve().parent
    cfg=load_r3_roll14(root,json.loads((root/PROFILE).read_text(encoding='utf8')))
    expected={int(i):p for i,p in cfg['targets'].items()}
    offsets={int(i):p for i,p in cfg['expected_offsets_raw'].items()}
    mapping_path=root/'visual_stand_mapping.json'
    if not mapping_path.exists():mapping_path=root/'sim2real_audit_20260928/reposed_start/visual_stand_mapping.json'
    direction_path=root/'FT_POLICY_AXIS_DIRECTIONS_20260928.json'
    direction_evidence=json.loads(direction_path.read_text(encoding='utf8')) if direction_path.exists() else None
    mapping=ShadowMapping(json.loads(mapping_path.read_text(encoding='utf8')),cfg,direction_evidence)
    policy=OriginalPolicy(args.policy_dir) if args.policy_dir else None
    cls,sha=load_reference(root/'reference_feetech.py')
    if sha!=BUS_SHA:raise ValueError('Original bus hash mismatch')
    import serial
    guard=GuardedSerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True),allow_same_start=False)
    bus=cls(PORT,ser=guard);imu=ImuTrace()
    result=dict(scope='LIVE_READ_ONLY_SHADOW_NEVER_EXECUTED_POLICY',profile=R3_NAME,
        profile_sha256=R3_SHA,reference_bus_sha256=sha,policy_inference=policy is not None,
        frames=[],motion_writes=0,configuration_writes=0,unknown_mapping_ids=list(mapping.unknown),
        direction_evidence_sha256=hashlib.sha256(direction_path.read_bytes()).hexdigest() if direction_evidence else None,
        current_raw_to_model_signs=mapping.sign,
        transport='10 legs sync-read plus all 5 heads individually fresh each tick',
        imu_mount='User confirmed axes body-aligned; exact rotation unmeasured. No automatic START leveling.',
        head_command='Derived R3 offset from original visual reference; approximate, not precision calibration.')
    def full_read():
        states={}
        for sid in range(1,16):
            err,data=bus.read(sid,0,66);q=decode(data)
            if (q['id']!=sid or q['mode']!=4 or q['offset']!=offsets[sid]):
                raise ValueError('Unexpected coordinate/ID/mode')
            decode_and_check(sid,err,data,0,expected)
            states[sid]=q
        return states
    try:
        result['before']=full_read();imu.start();epoch=time.monotonic();deadline=epoch
        skipped=0;consecutive_skipped=0
        for k in range(args.frames):
            time.sleep(max(0,deadline-time.monotonic()))
            begin=time.monotonic()
            # All-15 simultaneous replies showed real checksum failures on this
            # adapter. Reuse the already verified 10-leg sync transaction; read
            # every head freshly, rather than giving the actor cached 10Hz heads.
            rows=bus.sync_read(list(range(1,11)),40,26)
            for sid in range(11,16):rows[sid]=bus.read(sid,40,26)
            stamp=time.monotonic()
            if set(rows)!=set(expected) or any(v is None for v in rows.values()):
                skipped+=1;consecutive_skipped+=1
                result['frames'].append(dict(k=k,mono_s=stamp,t_s=stamp-epoch,
                    sample_valid=False,reason='INCOMPLETE_JOINT_READ_NO_INFERENCE',
                    missing_ids=[i for i in expected if rows.get(i) is None],
                    policy_shadow=None))
                if skipped>5 or consecutive_skipped>2:
                    raise RuntimeError('Repeated incomplete read-only samples')
                deadline+=.02
                if deadline<time.monotonic():deadline=time.monotonic()+.001
                continue
            consecutive_skipped=0
            states={i:decode_and_check(i,*rows[i],40,expected) for i in rows}
            ang=imu.latest.get(0x53);gyro=imu.latest.get(0x52)
            if imu.error or ang is None or gyro is None:raise RuntimeError('Missing IMU channels')
            ages=[(stamp-r['mono_s'])*1000 for r in (ang,gyro)]
            if min(ages)<-25 or max(ages)>150:raise RuntimeError('IMU not fresh for shadow input')
            q,qd,validity=mapping.coordinates({i:s['pos'] for i,s in states.items()},stamp)
            gravity=gravity_from_rpy_deg(ang['sensor_angles_deg'])
            gyro_rad=np.radians(gyro['sensor_gyro_dps'])
            command=mapping.r3_head_command()
            # 2s standing, 2s virtual forward, then standing. Robot does NOT move.
            if 100<=k<200:command[0]=.25
            pred=None;t0=time.monotonic()
            if policy and validity['velocity_valid']:
                pred=policy.step(q,qd,gyro_rad,gravity,command)
                pred['physical_shadow_targets']=mapping.targets(pred['policy_target_rad'])
            infer_ms=(time.monotonic()-t0)*1000
            result['frames'].append(dict(k=k,mono_s=stamp,t_s=stamp-epoch,sample_valid=True,
                read_ms=(stamp-begin)*1000,state=states,sensor_rpy_deg=ang['sensor_angles_deg'],
                sensor_gyro_dps=gyro['sensor_gyro_dps'],imu_age_ms=ages,
                q_approx_rad=q.tolist(),qdot_approx_rad_s=qd.tolist(),gyro_rad_s=gyro_rad.tolist(),
                projected_gravity=gravity.tolist(),command13=command.tolist(),mapping_validity=validity,
                policy_shadow=pred,inference_ms=infer_ms))
            deadline+=.02
            if deadline<time.monotonic():deadline=time.monotonic()+.001
        result['after']=full_read();result['status']='READ_ONLY_SHADOW_COMPLETE_NO_MOTION'
        result['skipped_incomplete_samples']=skipped
    except BaseException as exc:
        result.update(status='READ_ONLY_STOPPED_NO_MOTION',failure=repr(exc))
        raise
    finally:
        result['imu_trace']=imu.stop();result['bus_stats']=dict(bus.stats)
        result['packet_guard_counts']=dict(guard.tx);bus.close();result['serial_closed']=True
        path=root/('policy_shadow_inputs_'+str(time.time_ns())+'.json')
        path.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('frames','before','after','imu_trace')}),flush=True)
        print('LOG '+str(path),flush=True)


if __name__=='__main__':main()
