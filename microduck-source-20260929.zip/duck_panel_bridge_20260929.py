"""X5 one-job bridge. No HTTP listener; entered only through existing SSH.

Run is finite; all state-changing actions require explicit CLI action. Stop
requests create a job-specific cancellation marker, never a torque-off packet.
"""
import argparse
import base64
import contextlib
import hashlib
import json
import os
import re
import signal
import sys
import time
from pathlib import Path
from duck_tuning_config_20260929 import validate_parameters

ROOT=Path(__file__).resolve().parent
JOBS=ROOT/'panel_jobs_20260929'
JOB_RE=re.compile(r'^[0-9a-f]{32}$')


class OperatorStop(RuntimeError):pass


def emit(kind,**values):
    print(json.dumps(dict(panel_event=kind,**values),ensure_ascii=True),flush=True)


def job_path(job_id):
    if not isinstance(job_id,str) or not JOB_RE.fullmatch(job_id):raise ValueError('Invalid job ID')
    return JOBS/job_id


def config_from_b64(encoded):
    if not isinstance(encoded,str) or len(encoded)>2048:raise ValueError('Invalid configuration size')
    return validate_parameters(json.loads(base64.b64decode(encoded,validate=True)))


@contextlib.contextmanager
def ownership(job_id):
    import fcntl
    JOBS.mkdir(exist_ok=True)
    with (JOBS/'active.lock').open('a+b') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('BUSY: another panel job owns the robot')
        folder=job_path(job_id)
        folder.mkdir(exist_ok=False)
        (JOBS/'active.json').write_text(json.dumps(dict(job_id=job_id,pid=os.getpid())),encoding='utf8')
        try:yield folder
        finally:
            (JOBS/'active.json').write_text('{}',encoding='utf8')
            fcntl.flock(lock,fcntl.LOCK_UN)


def stop_job(job_id):
    job_path(job_id)
    JOBS.mkdir(exist_ok=True)
    # A request can arrive during SSH startup, before the job acquires ownership.
    # UUIDs are one-use, so the marker also cancels that pending job before I/O.
    (JOBS/(job_id+'.stop')).touch()
    emit('stop_requested',job_id=job_id)


def read_snapshot():
    # Independent read-only packet guard: this path cannot enable or move servos.
    from restore_all_r3_20260929 import load_r3_roll14,PROFILE,PORT,decode,load_reference,BUS_SHA
    from imu_trace_20260927 import ImuTrace
    cfg=load_r3_roll14(ROOT,json.loads((ROOT/PROFILE).read_text(encoding='utf8')))
    cls,sha=load_reference(ROOT/'reference_feetech.py')
    if sha!=BUS_SHA:raise RuntimeError('Bus source mismatch')
    import serial
    class ReadOnlySerial:
        def __init__(self,raw):self.raw=raw
        def write(self,p):
            if (len(p)!=8 or p[:2]!=b'\xff\xff' or not 1<=p[2]<=15 or p[3:7]!=bytes([4,2,0,66])
                or sum(p[2:])%256!=255):raise RuntimeError('Read-only guard rejected a non-READ packet')
            n=self.raw.write(p)
            if n!=len(p):raise IOError('Partial read request')
            return n
        def __getattr__(self,name):return getattr(self.raw,name)
    bus=cls(PORT,ser=ReadOnlySerial(serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True)))
    imu=ImuTrace()
    try:
        imu.start();rows={}
        for i in range(1,16):
            err,data=bus.read(i,0,66);rows[i]=decode(data);rows[i]['reply_error']=err
        time.sleep(.15)
        snapshot=imu.snapshot()
        r3=all(rows[i]['target']==cfg['targets'][str(i)] and rows[i]['torque']==1 for i in rows)
        result=dict(servos=rows,imu=snapshot,r3_targets_enabled=r3,physical_stability_unknown=True,
                    bus_stats=dict(bus.stats),motion_writes=0)
        emit('snapshot',**result);return result
    finally:imu.stop();bus.close()


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--action',choices=('about','plan','read','run','restore','stop'),required=True)
    p.add_argument('--job-id')
    p.add_argument('--config-base64')
    a=p.parse_args(argv)
    if a.action=='about':
        emit('about',domain=os.environ.get('ROS_DOMAIN_ID'),root=str(ROOT),
             files={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in (
                 'replay_verified_prefix_20260929.py','neck_prefix_compensation_20260929.py',
                 'restore_all_r3_20260929.py','duck_tuning_config_20260929.py',Path(__file__).name)})
        return 0
    params=config_from_b64(a.config_base64) if a.action in ('run','plan') else None
    if a.action=='plan':
        from replay_verified_prefix_20260929 import main as replay
        replay(['--neck-back-compensation'],panel_parameters=params)
        emit('plan',parameters=params,motion_writes=0);return 0
    job_path(a.job_id)
    if a.action=='stop':stop_job(a.job_id);return 0
    if os.environ.get('ROS_DOMAIN_ID')!='42':raise RuntimeError('Isolated environment required')
    with ownership(a.job_id) as folder:
        def cancel_check():
            if (JOBS/(a.job_id+'.stop')).exists():raise OperatorStop('OPERATOR_STOP: last goals held; no torque-off')
        def progress(value):
            cancel_check();emit('progress',**value)
        def interrupted(*_):raise OperatorStop('CONNECTION_OR_SIGNAL_STOP: last goals held')
        signal.signal(signal.SIGTERM,interrupted)
        if hasattr(signal,'SIGHUP'):signal.signal(signal.SIGHUP,interrupted)
        start=time.time();emit('started',job_id=a.job_id,action=a.action)
        try:
            cancel_check()
            if a.action=='run':
                from replay_verified_prefix_20260929 import main as replay
                result=replay(['--neck-back-compensation','--execute-with-onsite-catch'],
                    panel_parameters=params,panel_progress=progress,cancel_check=cancel_check)
            elif a.action=='restore':
                from restore_all_r3_20260929 import main as restore
                result=restore(['--restore-supported'],panel_progress=progress,cancel_check=cancel_check)
            else:result=read_snapshot()
            summary=dict(status='completed',action=a.action,job_id=a.job_id,parameters=params,
                elapsed_s=time.time()-start,result_status=result.get('status'),
                bus_stats=result.get('bus_stats'),motion_writes=result.get('motion_target_packets',result.get('volatile_write_packets',0)))
            emit('completed',**summary)
        except BaseException as exc:
            summary=dict(status='stopped' if isinstance(exc,OperatorStop) else 'failed',
                job_id=a.job_id,action=a.action,parameters=params,error=repr(exc),
                warning='No automatic torque-off or R3 reset. Support the robot before restore.')
            emit(summary['status'],**{k:v for k,v in summary.items() if k!='status'})
            (folder/'result.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
            return 2
        (folder/'result.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    return 0


if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:emit('failed',error=repr(exc));sys.exit(2)
