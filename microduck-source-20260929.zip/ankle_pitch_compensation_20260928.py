"""Small stance-ankle pitch feedback, candidate only; no robot I/O here."""
import math


def probe_frames(start):
    """2deg physical toe-down: raw5 decreases, raw10 increases; then return."""
    rows=[]
    def add(target,stage):rows.append(dict(target_raw=dict(target),stage=stage,provenance=None))
    for _ in range(150):add(start,'PROBE_BASELINE')
    down=dict(start);down[5]-=23;down[10]+=23
    for a,b,stage in ((start,down,'PROBE_TOE_DOWN'),(down,start,'PROBE_RETURN')):
        for k in range(1,51):
            u=k/50;w=u*u*(3-2*u)
            add({i:round(a[i]+(b[i]-a[i])*w) for i in a},stage)
        if stage=='PROBE_TOE_DOWN':
            for _ in range(50):add(down,'PROBE_HOLD_DOWN')
    for _ in range(25):add(start,'PROBE_FINAL_HOLD')
    return rows


def slow_source_frames(frames,rows):
    """Double only source-trajectory duration; no small-step amplitude scaling."""
    out=[];meta=[]
    for k,(frame,row) in enumerate(zip(frames,rows)):
        out.append(dict(frame));meta.append(dict(row))
        if (row['stage']=='ORIGINAL_START_TO_FORWARD_TO_STAND' and k+1<len(rows)
                and rows[k+1]['stage']==row['stage']):
            following=frames[k+1]
            f={i:round((frame[i]+following[i])/2) for i in frame}
            src=dict(row['provenance']);nxt=rows[k+1]['provenance']
            src['source_t_s']=(src['source_t_s']+nxt['source_t_s'])/2
            src['desired_reference_joint_rad']=[(a+b)/2 for a,b in zip(src['desired_reference_joint_rad'],nxt['desired_reference_joint_rad'])]
            out.append(f);meta.append(dict(row,target_raw=f,provenance=src))
    return out,meta


class AnklePitchCompensation:
    def __init__(self,reference):
        if not math.isfinite(reference):raise ValueError('Finite pitch reference required')
        self.reference=reference;self.offset={5:0.,10:0.};self.last=None
    def update(self,now,angles,gyro,age_ms,contacts,active,error=None):
        dt=.02 if self.last is None else max(0,min(.04,now-self.last));self.last=now
        valid=(angles is not None and gyro is not None and not error and age_ms<=100
               and all(math.isfinite(x) for x in [*angles,*gyro,now,age_ms]))
        info=dict(mode='STALE_IMU_HOLD_ANKLE_OFFSETS',pitch_reference_deg=self.reference)
        if valid:
            drift=(angles[1]-self.reference+180)%360-180
            roll=math.radians(angles[0]);rate=gyro[1]*math.cos(roll)-gyro[2]*math.sin(roll)
            correction=max(0,min(4.,.6*max(0,drift-.5)+.05*rate)) if active else 0.
            support=list(contacts) if contacts is not None else [True,True]
            if not any(support):support=[True,True]
            for i,planted in zip((5,10),support):
                desired=correction if planted else 0.
                self.offset[i]+=max(-30*dt,min(30*dt,desired-self.offset[i]))
            info.update(mode='STANCE_ANKLE_PITCH_PD',pitch_drift_deg=drift,pitch_rate_dps=rate,
                        requested_toe_down_deg=correction,predicted_support=support,
                        support_is_not_measured=True)
        counts={5:-round(self.offset[5]*4096/360),10:round(self.offset[10]*4096/360)}
        info['ankle_raw_corrections']=counts;info['ankle_toe_down_deg']=dict(self.offset)
        return counts,info
