"""Bounded IMU -> neck11 compensation around the explicit back2 candidate.

Not RL, not a proven balance controller. Positive observed pitch drift is the
user-confirmed forward direction. Neck11 raw decrease moves the head backward.
At most 8deg TOTAL from original raw2840; existing back2 is included.
"""
import math


class NeckPitchCompensation:
    def __init__(self,pitch_reference_deg):
        if not math.isfinite(pitch_reference_deg):raise ValueError('Finite reference needed')
        self.reference=pitch_reference_deg
        self.base_raw=2817
        self.limit_raw=2840-round(8*4096/360)
        self.command=float(self.base_raw)
        self.last=None
        self.kp=.5
        self.kd=.04
        self.slew_deg_s=12.
    def update(self,now,angles,gyro,age_ms,error=None):
        dt=.02 if self.last is None else max(0,min(.04,now-self.last))
        self.last=now
        valid=(angles is not None and gyro is not None and not error and age_ms<=100
               and all(math.isfinite(v) for v in [*angles,*gyro,now,age_ms]))
        if not valid:
            return round(self.command),dict(mode='STALE_IMU_HOLD_NECK_GAIT_CONTINUES',extra_back_deg=(self.base_raw-self.command)*360/4096)
        roll=math.radians(angles[0])
        pitch_rate=gyro[1]*math.cos(roll)-gyro[2]*math.sin(roll)
        drift=(angles[1]-self.reference+180)%360-180
        extra=max(0,min((self.base_raw-self.limit_raw)*360/4096,
                        self.kp*max(0,drift-.5)+self.kd*pitch_rate))
        desired=self.base_raw-extra*4096/360
        step=self.slew_deg_s*4096/360*dt
        self.command=max(self.limit_raw,min(self.base_raw,self.command+max(-step,min(step,desired-self.command))))
        raw=round(self.command)
        return raw,dict(mode='BOUNDED_PITCH_PD_NECK11',pitch_reference_deg=self.reference,
            pitch_drift_deg=drift,pitch_rate_dps=pitch_rate,requested_extra_back_deg=extra,
            actual_command_extra_back_deg=(self.base_raw-raw)*360/4096,
            total_command_back_from_original_deg=(2840-raw)*360/4096,
            command_raw=raw,gyro_age_ms=age_ms)


def feedback_snapshot(imu,now):
    angle=imu.latest.get(0x53);gyro=imu.latest.get(0x52)
    if not angle or not gyro:return None,None,float('inf'),imu.error
    age=max(now-angle['mono_s'],now-gyro['mono_s'])*1000
    return list(angle['sensor_angles_deg']),list(gyro['sensor_gyro_dps']),age,imu.error
