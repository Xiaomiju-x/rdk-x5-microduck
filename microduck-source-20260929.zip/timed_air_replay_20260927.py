"""50 Hz finite air-only transport trial, NOT a ground walking controller.

Retains the exact 286 previously air-tested encoder frames (max 15 degrees),
but sends one synchronous target packet per 20 ms instead of per-ID write/ACK
and 100 ms sleep. Torso MUST be supported and feet free. No EEPROM/torque/PID.
Default is offline plan validation. Only --execute-supported-air opens serial.
"""
import argparse
import hashlib
import json
from pathlib import Path
import signal
import time

from sync_cycle_probe_20260927 import START, OFFSETS, PORT, check_packet, load_reference, summarize

ROOT=Path(__file__).resolve().parent
ACTIVE={2,3,4,5,7,8,9,10}


def load_frames(path):
    data=json.loads(path.read_text(encoding='utf8'))
    if data['scope']!='SUPERVISED_SUSPENDED_MOTOR_SPACE_PREVIEW_ONLY' or data['ground_execution_allowed']:
        raise ValueError('Wrong plan scope')
    if {int(k):v for k,v in data['start_targets'].items()}!=START or {int(k):v for k,v in data['expected_offsets_raw'].items()}!=OFFSETS:
        raise ValueError('Wrong START/offset version')
    if set(data['active_ids'])!=ACTIVE or len(data['frames'])!=286:
        raise ValueError('Not the inspected finite air plan')
    result=[]; previous=dict(START)
    for partial in data['frames']:
        if set(map(int,partial))!=ACTIVE:
            raise ValueError('Wrong active IDs')
        frame=dict(START)
        frame.update({int(k):v for k,v in partial.items()})
        for i,v in frame.items():
            if type(v) is not int or not 0<=v<=4095 or abs(v-START[i])>171 or abs(v-previous[i])>4:
                raise ValueError('Trajectory exceeds already inspected position/step bounds')
        result.append(frame);previous=frame
    if result[0]!=START or result[-1]!=START:
        raise ValueError('Air plan must begin and end at START')
    return result


def position_payload(frame):
    if set(frame)!=set(START):
        raise ValueError('Missing servo target')
    return bytes([42,2])+b''.join(bytes([i,frame[i]&255,frame[i]>>8]) for i in START)


class PlanSerial:
    """Transmit allowlist; only current authorized plan frame can be written."""
    def __init__(self,raw):
        self.raw=raw
        self.allowed=None
        self.sync_writes=0

    def write(self,pkt):
        try:
            check_packet(pkt,False)
        except ValueError:
            if self.allowed is None or len(pkt)<6 or pkt[:3]!=b'\xff\xff\xfe' or pkt[4]!=0x83 or len(pkt)!=pkt[3]+4 or sum(pkt[2:])%256!=255 or pkt[5:-1]!=position_payload(self.allowed):
                raise ValueError('Rejected non-plan write')
            self.sync_writes+=1
            self.allowed=None  # one packet per authorization, no automatic retry
        count=self.raw.write(pkt)
        if count!=len(pkt):raise IOError('Partial transmit')
        return count

    def __getattr__(self,key):return getattr(self.raw,key)


class PositionTrackingLag(RuntimeError):
    """Only position lag; packet, torque, target and health already checked."""
    def __init__(self,sid,state):
        self.sid=sid;self.state=dict(state)
        super().__init__(f'ID{sid} position tracking lag {state}')


def check_state(sid,error,data,origin,expected):
    def byte(address):return data[address-origin]
    def word(address):return byte(address)+256*byte(address+1)
    q=dict(torque=byte(40),target=word(42),pos=word(56),voltage=byte(62)/10,temp=byte(63),error=byte(65))
    if origin==0 and (byte(5)!=sid or word(31)!=OFFSETS[sid] or byte(33)!=4):
        raise RuntimeError(f'ID{sid} identity/offset/mode changed')
    if error or q['error'] or q['torque']!=1 or q['target']!=expected[sid]:
        raise RuntimeError(f'ID{sid} command/reset/error mismatch {q}')
    if not 0<=q['pos']<=4095 or not 4<=q['voltage']<=8.4 or q['temp']>55:
        raise RuntimeError(f'ID{sid} health/tracking mismatch {q}')
    if abs(q['pos']-q['target'])>35:raise PositionTrackingLag(sid,q)
    return q


def execute_supported_frames(frames,info,reference_path,labels=None,max_increment_counts=4):
    if info.get('ground_execution_allowed') is not False or not 1<=len(frames)<=2000:
        raise ValueError('Air-only bounded sequence required')
    if not 1<=max_increment_counts<=14:
        raise ValueError('Supported velocity bound')
    if max_increment_counts>4 and (info.get('scope')!='SUPPORTED_RELATIVE_PAIR_TIMING_TRIAL' or info.get('max_increment_counts')!=max_increment_counts):
        raise ValueError('Faster timing is restricted to the separately reviewed relative pair trial')
    previous=dict(START)
    for frame in frames:
        if set(frame)!=set(START):raise ValueError('Missing IDs')
        for i,v in frame.items():
            if type(v) is not int or not 0<=v<=4095 or abs(v-START[i])>171 or abs(v-previous[i])>max_increment_counts:
                raise ValueError('Supported frame limit')
            if i not in ACTIVE and v!=START[i]:raise ValueError('Frozen joint changed')
        previous=frame
    if frames[0]!=START or frames[-1]!=START:raise ValueError('START endpoints required')
    import serial
    cls,sha=load_reference(reference_path)
    raw=serial.Serial(PORT,1000000,timeout=.005,write_timeout=.05,exclusive=True)
    guarded=PlanSerial(raw);bus=cls(PORT,ser=guarded)
    events=[];result=dict(info,status='PREFLIGHT',reference_sha256=sha,events=events)
    expected=dict(START)
    def cancel(*unused):raise RuntimeError('Interrupted; no automatic reset or torque-off')
    signal.signal(signal.SIGINT,cancel);signal.signal(signal.SIGTERM,cancel)
    def full_check():return {i:check_state(i,*bus.read(i,0,66),0,expected) for i in START}
    def runtime_check():
        data=bus.sync_read(list(range(1,11)),40,26)
        if any(v is None for v in data.values()):raise RuntimeError('Incomplete leg feedback')
        for i in range(11,16):data[i]=bus.read(i,40,26)
        return {i:check_state(i,*data[i],40,expected) for i in START}
    try:
        result['before']=full_check()
        epoch=time.monotonic()
        # Include a final 0.5 second hold for verified settling, no new pose.
        for k,frame in enumerate(frames+[START]*25):
            scheduled=epoch+k*.02
            time.sleep(max(0,scheduled-time.monotonic()))
            begun=time.monotonic()
            if begun-scheduled>.02:raise RuntimeError('Missed cycle: no catch-up burst')
            state=runtime_check()  # acknowledge previous frame before advancing
            if time.monotonic()-begun>.018:raise RuntimeError('Read budget exceeded; retain last bounded target')
            guarded.allowed=frame
            bus.sync_write(42,2,[(i,v.to_bytes(2,'little')) for i,v in frame.items()])
            raw.flush()
            expected=dict(frame)
            elapsed=time.monotonic()-begun
            events.append(dict(frame=k,t=begun-epoch,work_ms=elapsed*1000,state=state,command=frame))
            if elapsed>.02:raise RuntimeError('Cycle budget exceeded; no catch-up burst')
            if k%50==0:print(json.dumps(dict(frame=k,frames=len(frames),work_ms=elapsed*1000)),flush=True)
            if labels and k<len(labels) and (k==0 or labels[k]!=labels[k-1]):
                print(json.dumps(dict(frame=k,stage=labels[k])),flush=True)
        result['after']=full_check()
        result.update(status='CONTINUOUS_AIR_COMPLETE_NOT_GROUND_WALKING',
                      work_ms=summarize([v['work_ms'] for v in events]))
    except BaseException as exc:
        result.update(status='STOPPED_RETAIN_LAST_BOUNDED_TARGET',failure=repr(exc),last_command=expected)
        # No blind retries, no all-servo torque disable, no forced return sweep.
        # Software cannot guarantee a hold through power loss/bus failure.
        raise
    finally:
        result.update(sync_writes=guarded.sync_writes,reference_stats=dict(bus.stats))
        bus.close()
        output=ROOT/('timed_air_'+str(time.time_ns())+'.json')
        output.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps({k:v for k,v in result.items() if k not in ('events','before','after')}),flush=True)
        print('LOG '+str(output),flush=True)


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--plan',type=Path,default=ROOT/'suspended_preview_v4.json')
    cli.add_argument('--reference-path',type=Path,default=ROOT/'reference_feetech.py')
    cli.add_argument('--execute-supported-air',action='store_true')
    args=cli.parse_args()
    frames=load_frames(args.plan)
    info=dict(scope='CONTINUOUS_SUPPORTED_AIR_ONLY_NOT_WALKING',ground_execution_allowed=False,
              hardware_pose_mapping_verified=False,frames=len(frames),period_s=.02,
              nominal_sequence_seconds=len(frames)*.02,max_excursion_degrees=15,
              plan_sha256=hashlib.sha256(args.plan.read_bytes()).hexdigest())
    print(json.dumps(info),flush=True)
    if args.execute_supported_air:
        execute_supported_frames(frames,info,args.reference_path)


if __name__=='__main__':main()
