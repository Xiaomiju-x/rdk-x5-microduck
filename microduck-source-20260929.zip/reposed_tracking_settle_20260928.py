"""Bounded same-target hold for the new finite reference candidate.

The advance threshold stays 35 counts. A transient may occupy at most one
planned frame's extra error and 80 ms; never advance into increasing lag.
Not a fall-prevention controller or a change to the servo configuration.
"""


class BoundedReferenceSettle:
    def __init__(self, max_increment_counts):
        if type(max_increment_counts) is not int or not 1<=max_increment_counts<=14:
            raise ValueError('Reviewed slow reference increments only')
        self.cap=35+max_increment_counts
        self.since=None
        self.holds=0
        self.max_hold_ms=0.
    def choose(self, planned, expected, state, now):
        if set(state)!=set(range(1,16)) or set(expected)!=set(state) or set(planned)!=set(state):
            raise ValueError('Complete feedback required')
        for i,s in state.items():
            if (s['torque']!=1 or s['error'] or s['target']!=expected[i]
                    or not 0<=s['pos']<=4095 or not 4<=s['voltage']<=8.4 or s['temp']>55):
                raise RuntimeError('State/health mismatch during hold')
        lag={i:abs(s['pos']-expected[i]) for i,s in state.items()}
        if any(lag[i]>35 for i in (1,6,11,12,13,14,15)):
            raise RuntimeError('Stationary joint lag not eligible')
        if max(lag.values())>self.cap:raise RuntimeError('Beyond one-frame transient lag')
        if self.since is not None and now-self.since>=.08:
            raise RuntimeError('Lag did not clear in under 80ms')
        if max(lag.values())<=35:
            if self.since is not None:self.max_hold_ms=max(self.max_hold_ms,(now-self.since)*1000)
            self.since=None
            return dict(planned),True
        if self.since is None:self.since=now
        self.holds+=1
        if self.holds>20:raise RuntimeError('Finite total hold budget exceeded')
        self.max_hold_ms=max(self.max_hold_ms,(now-self.since)*1000)
        return dict(expected),False
