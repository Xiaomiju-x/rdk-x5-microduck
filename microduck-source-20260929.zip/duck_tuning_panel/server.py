"""Loopback-only tuning UI. Existing SSH key is used; never accepts shell text."""
import argparse
import base64
import copy
import ipaddress
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from duck_tuning_config_20260929 import DEFAULTS,LIMITS,OUTCOMES,validate_parameters,validate_ballast

REMOTE_ROOT='/home/sunrise/workspaces/microduck/duck_calibration_20260926'
BRIDGE='duck_panel_bridge_20260929.py'
JOB_RE=re.compile(r'^[0-9a-f]{32}$')


def write_json(path,value):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
    os.replace(temporary,path)


def ssh_command(host,action,job_id=None,parameters=None):
    ip=ipaddress.ip_address(host)
    if ip.version!=4 or not ip.is_private:raise ValueError('X5 must use a private IPv4 address')
    if action not in ('run','restore','read','stop','about','plan'):raise ValueError('Unsupported action')
    tail=f'.venv_policy_shadow_20260928/bin/python -u {BRIDGE} --action {action}'
    if action not in ('about','plan'):
        if not JOB_RE.fullmatch(job_id or ''):raise ValueError('Invalid job ID')
        tail+=' --job-id '+job_id
    if action in ('run','plan'):
        config=validate_parameters(parameters)
        encoded=base64.b64encode(json.dumps(config,separators=(',',':')).encode()).decode()
        tail+=' --config-base64 '+encoded
    command=f'cd /home/sunrise/workspaces/microduck && . ./env.sh && cd {REMOTE_ROOT} && {tail}'
    return ['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=8',
            '-o','ServerAliveInterval=3','-o','ServerAliveCountMax=3',f'sunrise@{host}',command]


class Manager:
    def __init__(self,host,storage,demo=False):
        self.host=host;self.storage=Path(storage);self.storage.mkdir(parents=True,exist_ok=True)
        self.demo=demo;self.lock=threading.RLock();self.active=None;self.last=None
        self.jobs={};self.token=secrets.token_urlsafe(32)
        self.preset=dict(parameters=dict(DEFAULTS),ballast=dict(position='unchanged',note=''))
        for path in sorted(self.storage.glob('*.json')):
            if not JOB_RE.fullmatch(path.stem):continue
            try:
                job=json.loads(path.read_text(encoding='utf8'))
                if job.get('status') in ('starting','running','stopping'):
                    job.update(status='unknown',error='服务重启；不推测鸭子已复位，请先读取状态。')
                self.jobs[path.stem]=job
            except (ValueError,OSError):continue
        saved=self.storage/'preset.json'
        if saved.exists():
            try:
                p=json.loads(saved.read_text(encoding='utf8'))
                self.preset=dict(parameters=validate_parameters(p['parameters']),ballast=validate_ballast(p['ballast']))
            except (ValueError,KeyError):pass

    def save(self,job):write_json(self.storage/(job['id']+'.json'),job)

    def snapshot(self):
        with self.lock:
            history=sorted(self.jobs.values(),key=lambda j:j['started_at'],reverse=True)[:20]
            keys=('id','action','parameters','ballast','status','started_at','ended_at','outcome','outcome_note','demo','error')
            history=[{k:j[k] for k in keys if k in j} for j in history]
            return copy.deepcopy(dict(busy=self.active is not None,active=self.active,
                current=self.jobs.get(self.active or self.last),history=history,demo=self.demo,host=self.host))

    def start(self,request):
        if not isinstance(request,dict) or set(request)!={'action','parameters','ballast','onsite','supported'}:
            raise ValueError('请求格式错误')
        action=request['action']
        if action not in ('run','restore','read'):raise ValueError('动作无效')
        parameters=validate_parameters(request['parameters']);ballast=validate_ballast(request['ballast'])
        if action=='run' and request['onsite'] is not True:raise ValueError('请确认鸭子站稳且有人接护')
        if action=='restore' and request['supported'] is not True:raise ValueError('复位前请托稳躯干与头部')
        with self.lock:
            if self.active is not None:raise RuntimeError('BUSY：当前动作尚未结束，不排队')
            job_id=uuid.uuid4().hex
            job=dict(id=job_id,action=action,parameters=parameters,ballast=ballast,
                status='starting',started_at=time.time(),progress=None,events=[],telemetry=[],
                outcome='unreviewed',outcome_note='',stop_requested=False,demo=self.demo)
            self.jobs[job_id]=job;self.active=job_id;self.last=job_id;self.save(job)
            threading.Thread(target=self.work,args=(job_id,),daemon=True).start()
            return dict(job_id=job_id)

    def event(self,job,event):
        with self.lock:
            kind=event.get('panel_event')
            if kind=='started':job['status']='running'
            elif kind=='progress':job['progress']=event;job.setdefault('telemetry',[]).append(event)
            elif kind=='snapshot':job['snapshot']=event
            elif kind in ('completed','stopped','failed'):
                job['status']=kind;job['result']=event
                if kind=='failed':job['error']=event.get('error','板端失败')
            else:return
            if kind!='progress':job['events'].append(event)
            self.save(job)

    def work(self,job_id):
        job=self.jobs[job_id]
        try:
            if self.demo:self.demo_work(job)
            else:
                args=ssh_command(self.host,job['action'],job_id,job['parameters'])
                flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
                with (self.storage/(job_id+'.log')).open('w',encoding='utf8') as log:
                    process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                        text=True,encoding='utf8',errors='replace',bufsize=1,creationflags=flags)
                    for line in process.stdout:
                        log.write(line);log.flush()
                        try:
                            event=json.loads(line)
                            if isinstance(event,dict):self.event(job,event)
                        except ValueError:pass
                    code=process.wait()
                    if code!=0 and job['status'] not in ('failed','stopped'):
                        raise RuntimeError('SSH/板端任务异常退出。当前姿态未知，先托稳；日志已保存。')
                    if job['status'] not in ('completed','failed','stopped'):
                        raise RuntimeError('未收到板端完成回执，不能认定已复位。')
        except Exception as exc:
            with self.lock:job.update(status='failed',error=str(exc))
        finally:
            with self.lock:
                job['ended_at']=time.time();self.save(job);self.active=None

    def demo_work(self,job):
        self.event(job,dict(panel_event='started'))
        if job['action']=='read':
            self.event(job,dict(panel_event='snapshot',r3_targets_enabled=True,servos={},demo=True))
        else:
            for frame in range(0,400,10):
                with self.lock:cancel=job['stop_requested']
                if cancel:
                    self.event(job,dict(panel_event='stopped',demo=True));return
                phase='PREPARE_EXACT_R3' if frame<150 else 'EXACT_SENT_TARGET_PREFIX' if frame<250 else 'GENERATED_SMOOTH_R3' if frame<350 else 'FINAL_R3_HOLD'
                self.event(job,dict(panel_event='progress',frame=frame,total=400,phase=phase,elapsed_s=frame*.02,
                                    pitch_deg=0,compensation_deg=0,demo=True))
                time.sleep(.1)
        self.event(job,dict(panel_event='completed',demo=True))

    def stop(self,job_id):
        with self.lock:
            if self.active!=job_id:raise ValueError('这轮已结束，没有待停止任务')
            job=self.jobs[job_id];job['stop_requested']=True;self.save(job)
        if not self.demo:
            threading.Thread(target=self.deliver_stop,args=(job,),daemon=True).start()
        return dict(requested=True,confirmed_stopped=False)

    def deliver_stop(self,job):
        try:
            flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
            result=subprocess.run(ssh_command(self.host,'stop',job['id']),capture_output=True,
                text=True,encoding='utf8',errors='replace',timeout=15,creationflags=flags)
            if result.returncode:raise RuntimeError('停止请求未确认送达，请现场接护；不是硬件急停')
            with self.lock:job['stop_delivery']='sent_not_yet_stopped';self.save(job)
        except Exception as exc:
            with self.lock:job['stop_delivery']=str(exc);self.save(job)

    def outcome(self,request):
        if set(request)!={'job_id','outcome','note'}:raise ValueError('结果记录格式错误')
        if request['outcome'] not in OUTCOMES or not isinstance(request['note'],str) or len(request['note'])>300:
            raise ValueError('结果或备注无效')
        with self.lock:
            job=self.jobs[request['job_id']]
            job.update(outcome=request['outcome'],outcome_note=request['note']);self.save(job)
        return dict(saved=True)


def handler_for(manager,port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*_):pass
        def valid_host(self):return self.headers.get('Host') in (f'127.0.0.1:{port}',f'localhost:{port}')
        def respond(self,status,value,content_type='application/json; charset=utf-8'):
            data=json.dumps(value,ensure_ascii=False).encode() if content_type.startswith('application/json') else value
            self.send_response(status);self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY')
            self.send_header('Cross-Origin-Resource-Policy','same-origin')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers();self.wfile.write(data)
        def do_GET(self):
            if not self.valid_host():self.respond(403,dict(error='Host rejected'));return
            path=urlsplit(self.path).path
            if path=='/api/config':
                self.respond(200,dict(csrf=manager.token,defaults=DEFAULTS,limits=LIMITS,preset=manager.preset,
                    host=manager.host,demo=manager.demo,app='microduck-local-tuning-v1'));return
            if path=='/api/status':self.respond(200,manager.snapshot());return
            if path.startswith('/api/log/'):
                key=path.removeprefix('/api/log/')
                if not JOB_RE.fullmatch(key) or key not in manager.jobs:self.respond(404,{});return
                with manager.lock:self.respond(200,copy.deepcopy(manager.jobs[key]));return
            assets={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),
                    '/style.css':('style.css','text/css; charset=utf-8')}
            if path not in assets:self.respond(404,{});return
            name,mime=assets[path];self.respond(200,(HERE/name).read_bytes(),mime)
        def do_POST(self):
            if (not self.valid_host() or self.headers.get('Origin') not in
                (f'http://127.0.0.1:{port}',f'http://localhost:{port}') or
                self.headers.get('X-CSRF-Token')!=manager.token):
                self.respond(403,dict(error='来源或会话校验失败，请刷新本机面板'));return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=16384 or self.headers.get('Content-Type')!='application/json':
                    raise ValueError('Only bounded JSON requests are accepted')
                value=json.loads(self.rfile.read(length))
                if not isinstance(value,dict):raise ValueError('JSON object required')
                path=urlsplit(self.path).path
                if path=='/api/start':result=manager.start(value)
                elif path=='/api/stop':
                    if set(value)!={'job_id'}:raise ValueError('Invalid stop request')
                    result=manager.stop(value['job_id'])
                elif path=='/api/outcome':result=manager.outcome(value)
                elif path=='/api/preset':
                    if set(value)!={'parameters','ballast'}:raise ValueError('Invalid preset')
                    result=dict(parameters=validate_parameters(value['parameters']),ballast=validate_ballast(value['ballast']))
                    with manager.lock:manager.preset=result;write_json(manager.storage/'preset.json',result)
                else:self.respond(404,{});return
                self.respond(200,result)
            except RuntimeError as exc:self.respond(409,dict(error=str(exc)))
            except (ValueError,KeyError,TypeError) as exc:self.respond(400,dict(error=str(exc)))
    return Handler


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',type=int,default=9184);p.add_argument('--host',default='127.0.0.1')
    p.add_argument('--demo',action='store_true');p.add_argument('--storage',type=Path)
    a=p.parse_args()
    if not a.demo:p.error('Public snapshot is demo-only by default; read DEPLOYMENT.md before adapting a physical robot')
    if not 9100<=a.port<=9199:p.error('Port must stay in 9100..9199')
    ssh_command(a.host,'about')
    storage=a.storage or HERE/('demo_records' if a.demo else 'records')
    manager=Manager(a.host,storage,a.demo)
    server=ThreadingHTTPServer(('127.0.0.1',a.port),handler_for(manager,a.port));server.daemon_threads=True
    print(f'MicroDuck panel http://127.0.0.1:{a.port}/ mode={"DEMO" if a.demo else "LIVE"}',flush=True)
    server.serve_forever()


if __name__=='__main__':main()
