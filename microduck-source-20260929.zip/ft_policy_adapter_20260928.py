"""Original 61/14 policy contract and SHADOW-ONLY FT coordinate adapter.

No serial/motion API. Four joint signs and precise model zeros remain unverified.
The shadow uses an explicit held-HOME approximation for those four inputs and
returns None for their physical outputs, never silently fabricating signs.
"""
import hashlib
import json
import math
from pathlib import Path
import numpy as np

IDS=(1,2,3,4,5,11,12,13,14,6,7,8,9,10)
JOINTS=('left_hip_yaw','left_hip_roll','left_hip_pitch','left_knee','left_ankle',
        'neck_pitch','head_pitch','head_yaw','head_roll','right_hip_yaw',
        'right_hip_roll','right_hip_pitch','right_knee','right_ankle')
DEFAULT=np.array([0.,-.0873,-.4579,-.0049,.4530,.3491,.3491,0.,0.,0.,.0873,.4579,.0049,-.4530],dtype=np.float32)
SHAS={'walking':'e36332d383997d51401897734cd3e79cf5038406feddb18b4d57ecfb141daa6c',
      'standing':'1569268713e40deea795dd2922dba50d3621e15a872855408b6b1b125b1c094b'}
FILES={'walking':'alpha_walking.onnx','standing':'alpha_stand.onnx'}
UNKNOWN=(1,6,13,14)
RAD_PER_COUNT=2*math.pi/4096


def vec(value,n):
    result=np.asarray(value,dtype=np.float32)
    if result.shape!=(n,) or not np.isfinite(result).all():
        raise ValueError('Finite vector length '+str(n)+' required')
    return result


def observation(q,qdot,gyro_rad_s,gravity,last_action,command):
    gravity=vec(gravity,3)
    if abs(float(np.linalg.norm(gravity))-1)>.01:
        raise ValueError('Projected gravity must be a unit vector')
    return np.concatenate((vec(gyro_rad_s,3),gravity,vec(q,14)-DEFAULT,
                           vec(qdot,14),vec(last_action,14),vec(command,13))).astype(np.float32)


def gravity_from_rpy_deg(rpy):
    """R_world_sensor = Rz(yaw) Ry(pitch) Rx(roll); no auto-zero at START.

    Sensor axes assumed body-aligned per user; exact mounting rotation unmeasured.
    Returns R^T*[0,0,-1], not raw accelerometer and not Euler derivatives.
    """
    roll,pitch,_=np.radians(vec(rpy,3)).astype(float)
    return np.array([math.sin(pitch),-math.sin(roll)*math.cos(pitch),
                     -math.cos(roll)*math.cos(pitch)],dtype=np.float32)


def visual_stand_mount_candidate(sensor_reference_rpy_deg):
    """Candidate R_body_sensor, CONDITIONAL on reference torso actually upright.

    Not an automatic calibration. This hypothesis is for shadow comparison;
    it does not establish a measured mounting rotation or authorize motion.
    Yaw is deliberately unconstrained: body and sensor forward axes are assumed
    aligned in yaw by the user's mounting confirmation.
    """
    roll,pitch,_=np.radians(vec(sensor_reference_rpy_deg,3)).astype(float)
    rx=np.array([[1,0,0],[0,math.cos(roll),-math.sin(roll)],[0,math.sin(roll),math.cos(roll)]])
    ry=np.array([[math.cos(pitch),0,math.sin(pitch)],[0,1,0],[-math.sin(pitch),0,math.cos(pitch)]])
    return ry@rx


def rotate_sensor_vectors(gravity_sensor,gyro_sensor_rad_s,body_from_sensor):
    r=np.asarray(body_from_sensor,dtype=float)
    if r.shape!=(3,3) or not np.isfinite(r).all() or not np.allclose(r.T@r,np.eye(3),atol=1e-6) or not np.isclose(np.linalg.det(r),1,atol=1e-6):
        raise ValueError('Proper fixed mounting rotation required')
    return ((r@vec(gravity_sensor,3)).astype(np.float32),
            (r@vec(gyro_sensor_rad_s,3)).astype(np.float32))


class OriginalPolicy:
    def __init__(self,directory):
        import onnxruntime as ort
        self.sessions={}
        opts=ort.SessionOptions();opts.intra_op_num_threads=1;opts.inter_op_num_threads=1
        for mode,filename in FILES.items():
            path=Path(directory)/filename
            if hashlib.sha256(path.read_bytes()).hexdigest()!=SHAS[mode]:
                raise ValueError('Unexpected original policy '+mode)
            session=ort.InferenceSession(str(path),sess_options=opts,providers=['CPUExecutionProvider'])
            if session.get_inputs()[0].shape[-1]!=61 or session.get_outputs()[0].shape[-1]!=14:
                raise ValueError('Wrong observation/action contract')
            md=session.get_modelmeta().custom_metadata_map
            if tuple(md['joint_names'].split(','))!=JOINTS or float(md['action_scale'])!=1:
                raise ValueError('Wrong joint order or action scale')
            if md['observation_names']!='base_ang_vel,projected_gravity,joint_pos,joint_vel,actions,command,head_command,body_command':
                raise ValueError('Wrong observation semantics')
            self.sessions[mode]=session
        self.last_action=np.zeros(14,dtype=np.float32)

    def evaluate(self,obs,mode):
        obs=vec(obs,61)
        session=self.sessions[mode]
        action=session.run([session.get_outputs()[0].name],{session.get_inputs()[0].name:obs[None,:]})[0]
        action=vec(np.asarray(action).reshape(-1),14)
        return action,(DEFAULT+action).astype(np.float32)

    def step(self,q,qdot,gyro_rad_s,gravity,command):
        command=vec(command,13)
        mode='standing' if np.linalg.norm(command[:3])<=.05 else 'walking'
        # Match the author's switch: do not reset last action at policy changes.
        if mode=='standing':
            command=command.copy();command[:3]=0
        obs=observation(q,qdot,gyro_rad_s,gravity,self.last_action,command)
        action,target=self.evaluate(obs,mode)
        self.last_action=action.copy()
        return dict(mode=mode,observation=obs.tolist(),action_raw=action.tolist(),
                    policy_target_rad=target.tolist(),action_scale=1.)


class ShadowMapping:
    def __init__(self,mapping,r3,direction_evidence=None):
        self.mapping=mapping
        self.r3={int(i):v for i,v in r3['targets'].items()}
        self.qref={i:float(mapping['joints'][str(i)]['q_at_visual_reference_rad']) for i in IDS}
        self.rawref={i:int(mapping['start_targets'][str(i)]) for i in IDS}
        self.sign={i:mapping['joints'][str(i)]['raw_increase_upstream_sign'] for i in IDS}
        # CURRENT physical result: full-body check 2026-09-28 ID11 raw+114 moved
        # backward, opposite the old record. Original neck axis -Y => sign +1.
        # ID12 was also physically reversed: raw+ lowers beak (forward pitch),
        # original head axis +Y => sign +1. Both old neck signs are superseded.
        # No EEPROM direction bit or saved R3 target is modified.
        self.sign.update({11:1,12:1})
        if any(self.sign[i] is not None for i in UNKNOWN):
            raise ValueError('Do not silently upgrade unverified yaw/roll signs')
        self.observed_ids=set()
        if direction_evidence is not None:
            from head_retaught_r2_profile_20260928 import R3_SHA
            if direction_evidence['profile_sha256']!=R3_SHA:
                raise ValueError('Direction evidence is for another coordinate session')
            for key,row in direction_evidence['newly_observed'].items():
                sid=int(key);sign=row['raw_increase_upstream_sign']
                if (sid not in (*UNKNOWN,11,12) or sign not in (-1,1) or row['raw_delta']!=114
                        or not row.get('user_reply_verbatim') or not row.get('returned_to_R3')):
                    raise ValueError('Incomplete user-observed direction evidence')
                self.sign[sid]=sign
                self.observed_ids.add(sid)
        self.unknown=tuple(i for i in IDS if self.sign[i] is None)
        self.previous=None

    def coordinates(self,positions,stamp):
        q=np.array([self.qref[i] if self.sign[i] is None else
            self.qref[i]+self.sign[i]*(positions[i]-self.rawref[i])*RAD_PER_COUNT for i in IDS],dtype=np.float32)
        velocity_valid=self.previous is not None
        qdot=np.zeros(14,dtype=np.float32)
        if self.previous is not None:
            old_t,old_q=self.previous;dt=stamp-old_t
            if not .001<=dt<=.2:raise ValueError('Invalid position-difference sample interval')
            qdot=(q-old_q)/dt
        self.previous=(stamp,q.copy())
        return q,qdot,dict(velocity_valid=velocity_valid,
            qdot_source='position finite difference at sync-read batch completion; not exact per-ID arrival time',
            unknown_input_ids_held_at_approximate_home=list(self.unknown),
            mechanical_zero_precision_verified=False,
            head_pitch_signs_derived_not_new_motion_verified=not {11,12}.issubset(self.observed_ids))

    def r3_head_command(self):
        command=np.zeros(13,dtype=np.float32)
        for idx,sid in ((3,11),(4,12),(5,13),(6,14)):
            if self.sign[sid] is None:continue
            q=self.qref[sid]+self.sign[sid]*(self.r3[sid]-self.rawref[sid])*RAD_PER_COUNT
            command[idx]=q-float(DEFAULT[IDS.index(sid)])
        return command

    def targets(self,target_rad):
        target=vec(target_rad,14);raw={};warnings=[]
        for i,q in zip(IDS,target):
            if self.sign[i] is None:
                raw[i]=None;warnings.append(dict(id=i,reason='UNVERIFIED_SIGN_NO_PHYSICAL_TARGET'))
                continue
            p=round(self.rawref[i]+self.sign[i]*(float(q)-self.qref[i])/RAD_PER_COUNT)
            raw[i]=p
            if not 0<=p<=4095:warnings.append(dict(id=i,reason='ENCODER_RANGE',raw=p))
            # Audit against previously explored +/-25deg envelope, NOT a silent
            # limiter and NOT a release criterion for full-policy execution.
            if abs(p-self.r3[i])>284:warnings.append(dict(id=i,reason='OUTSIDE_PREVIOUS_REFERENCE_ENVELOPE',raw=p))
        return dict(raw_unclipped_shadow=raw,warnings=warnings,motion_allowed=False,
                    eeprom_offsets_added_again=False)
