"""Finite R3-to-policy authority ramp; no hardware, observer or policy changes.

This is an explicit experimental deployment adapter, NOT original-policy
equivalence. It disappears after one second. No EMA or last_action substitution.
"""
import math


def takeover_weight(elapsed_s, duration_s):
    if not math.isfinite(elapsed_s) or not math.isfinite(duration_s):
        raise ValueError('Finite time required')
    if duration_s not in (0., 1.):
        raise ValueError('Only baseline or declared one-second takeover')
    if duration_s == 0:
        return 1.
    u = max(0., min(1., elapsed_s / duration_s))
    return u * u * (3. - 2. * u)


def blend_takeover(raw, start, caps_deg, elapsed_s, duration_s):
    """Cap first, then ramp all 14 joints together from the unchanged R3.

    The existing per-axis slew/envelope guard must still be applied afterwards.
    At weight one return raw exactly, preserving all baseline clipping receipts.
    """
    if set(raw) != set(caps_deg) or not set(raw).issubset(start):
        raise ValueError('Complete declared joint set required')
    if any(type(v) is not int for v in raw.values()):
        raise ValueError('Integer targets required')
    alpha = takeover_weight(elapsed_s, duration_s)
    if alpha == 1:
        return dict(raw), alpha
    result = {}
    for sid, value in raw.items():
        cap = round(caps_deg[sid] * 4096 / 360)
        capped = max(start[sid] - cap, min(start[sid] + cap, value))
        result[sid] = round(start[sid] + alpha * (capped - start[sid]))
    return result, alpha
