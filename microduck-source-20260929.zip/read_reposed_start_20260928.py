"""Read-only current START + passive IMU capture. No motion/config writes."""
import json
import hashlib
from pathlib import Path
import time

from imu_trace_20260927 import ImuTrace
from servo_link_diagnostic import framed_read

PROFILE = 'FT_START_POSE_20260928_ORIGINAL_IDS_REPOSED.json'
PORT = '/dev/serial/by-id/SELECT_SERVO_ADAPTER'


def decode(data):
    def word(a): return data[a] + 256 * data[a+1]
    p = word(56)
    return dict(id=data[5], mode=data[33], torque=data[40], target=word(42),
                pos=-(p & 32767) if p & 32768 else p, offset=word(31),
                speed_raw=word(58), load_raw=word(60), voltage=data[62]/10,
                temp=data[63], error=data[65])


def main():
    import serial
    root = Path(__file__).resolve().parent
    profile = root/PROFILE
    cfg = json.loads(profile.read_text(encoding='utf8'))
    target = {int(k):v for k,v in cfg['targets'].items()}
    offset = {int(k):v for k,v in cfg['expected_offsets_raw'].items()}
    result = dict(scope='REPOSED_START_READ_ONLY', profile=PROFILE,
                  profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest(),
                  motion_writes=0, configuration_writes=0, records=[])
    imu = ImuTrace()
    try:
        with serial.Serial(PORT, 1000000, timeout=.005, write_timeout=.1,
                           exclusive=True) as port:
            def read(i):
                # Only opcode 2 (READ). No generic send/write API is exposed.
                b = [i, 4, 2, 0, 66]
                port.reset_input_buffer()
                begun = time.monotonic()
                port.write(bytes([255,255]+b+[255-sum(b)%256]))
                port.flush()
                f, discarded, _ = framed_read(port, i)
                q = decode(f[5:-1])
                q.update(host_midpoint_s=(begun+time.monotonic())/2,
                         read_duration_ms=(time.monotonic()-begun)*1000,
                         discarded=discarded)
                if q['id'] != i or q['mode'] != 4 or q['offset'] != offset[i]:
                    raise RuntimeError('ID/mode/offset mismatch '+str(q))
                if q['torque'] != 1 or q['target'] != target[i]:
                    raise RuntimeError('Not holding saved START '+str(q))
                if q['error'] or not 4 <= q['voltage'] <= 8.4 or q['temp'] > 55:
                    raise RuntimeError('Health mismatch '+str(q))
                if not 0 <= q['pos'] <= 4095 or abs(q['pos']-target[i]) > 35:
                    raise RuntimeError('Position mismatch '+str(q))
                return q
            result['before'] = {i:read(i) for i in range(1,16)}
            imu.start()
            epoch = time.monotonic()
            for k in range(100):
                begin = time.monotonic()
                row = dict(t=begin-epoch, state={i:read(i) for i in range(1,16)},
                           imu=imu.snapshot())
                row['work_ms'] = (time.monotonic()-begin)*1000
                result['records'].append(row)
                time.sleep(max(0, .05-(time.monotonic()-begin)))
            result['after'] = {i:read(i) for i in range(1,16)}
            result['status'] = 'ALL15_CURRENT_START_READBACK_PASS'
    except BaseException as exc:
        result.update(status='READ_FAILED_NO_RECOVERY_WRITES', failure=repr(exc))
        raise
    finally:
        result['imu_trace'] = imu.stop()
        result['serial_closed'] = True
        output = root/('reposed_start_readonly_'+str(time.time_ns())+'.json')
        output.write_text(json.dumps(result, indent=2), encoding='utf8')
        print(json.dumps({k:v for k,v in result.items()
                          if k not in ('before','after','records','imu_trace')}))
        print('LOG '+str(output), flush=True)


if __name__ == '__main__': main()
